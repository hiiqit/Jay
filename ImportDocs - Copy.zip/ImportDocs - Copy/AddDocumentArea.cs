﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FileNet.Api.Core;
using FileNet.Api.Constants;
using FileNet.Api.Admin;
using FileNet.Api.Meta;
using FileNet.Api.Collection;
using FileNet.Api.Property;
using FileNet.Api.Exception;
using FileNet.Api.Query;

namespace AdminImaging
{
   public partial class AddDocumentArea : Form
   {
      private IObjectStore FNStore;
      public AddDocumentArea(IObjectStore fnStore)
      {
         FNStore = fnStore;
         InitializeComponent();
      }

      private void button1_Click(object sender, EventArgs e)
      {
         //Validation Routine
         if (!ValidateData())
            return;

         IFolder folder = FileNetActions.CreateFolder(FNStore, "", textBox1.Text);

         IFolder logFolder = folder.CreateSubFolder("Logs");
         logFolder.Save(RefreshMode.NO_REFRESH);

         MessageBox.Show("Document Area created successfully!", "Admin Imaging Create Document Area");
         DialogResult = DialogResult.OK;
         this.Close();
      }

      private bool ValidateData()
      {
         if (string.IsNullOrEmpty(textBox1.Text))
         {
            MessageBox.Show("Please enter a Document Area", "Admin Imaging Create Document Area");
            return false;
         }

         if (textBox1.Text.Length > 20)
         {
            MessageBox.Show("Please keep the Document Area name to 20 characters or less", "Admin Imaging Create Document Area");
            return false;
         }

         try
         {
            string baseFolderPath = "/";
            string strFolderPath = baseFolderPath + textBox1.Text;

            //try to get the new category
            IFolder folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);

            MessageBox.Show("Document Area already exists. Please enter a new Document Area", "Admin Imaging Create Document Area");
            return false;
         }
         catch (Exception)
         {
         }

         return true;
      }

      private void button2_Click(object sender, EventArgs e)
      {
         DialogResult = DialogResult.Cancel;
         this.Close();
      }
   }
}
