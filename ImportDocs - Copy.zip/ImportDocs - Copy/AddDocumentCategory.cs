﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FileNet.Api.Core;
using FileNet.Api.Constants;
using FileNet.Api.Admin;
using FileNet.Api.Meta;
using FileNet.Api.Collection;
using FileNet.Api.Property;

namespace AdminImaging
{
    public partial class AddDocumentCategory : Form
    {
        private IObjectStore FNStore;
        public AddDocumentCategory(IObjectStore fnStore)
        {
            FNStore = fnStore;
            InitializeComponent();

            //setup document areas
            IFolder folder = Factory.Folder.FetchInstance(FNStore, "/", null);
            foreach (IFolder subFolder in folder.SubFolders)
            {
                try
                {
                    if ((Boolean) subFolder.Properties[FileNetConstants.DocumentAreaIndicator] == true)
                    {
                        comboBox1.Items.Add(subFolder.Name);
                    }
                }
                catch (Exception)
                {
                }

            }
            comboBox1.Sorted = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Validation Routine
            if (!ValidateData())
                return;

            FileNetActions.CreateFolder(FNStore, comboBox1.SelectedItem.ToString(), textBox1.Text);
            
            MessageBox.Show("Document Category created successfully!", "Admin Imaging Create Document Category");
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(comboBox1.Text))
            {
                MessageBox.Show("Please select a Document Area", "Admin Imaging Create Document Category");
                return false;
            }

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please enter a Document Category", "Admin Imaging Create Document Category");
                return false;
            }

            try
            {
                string baseFolderPath = "/" + comboBox1.SelectedItem.ToString();
                string strFolderPath = baseFolderPath + "/" + textBox1.Text;

                //try to get the new category
                IFolder folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);

                MessageBox.Show("Document Category already exists. Please enter a new Document Category", "Admin Imaging Create Document Category");
                return false;
            }
            catch (Exception)
            {
            }

            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
