﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FileNet.Api.Core;
using FileNet.Api.Constants;
using FileNet.Api.Admin;
using FileNet.Api.Meta;
using FileNet.Api.Collection;
using FileNet.Api.Exception;

namespace AdminImaging
{
   public partial class AddDocumentType : Form
   {
      private IObjectStore FNStore;
      public AddDocumentType(IObjectStore fnStore)
      {
         FNStore = fnStore;
         InitializeComponent();

         //setup document areas
         IFolder folder = Factory.Folder.FetchInstance(FNStore, "/", null);
         foreach (IFolder subFolder in folder.SubFolders)
         {
            try
            {
               if ((Boolean)subFolder.Properties[FileNetConstants.DocumentAreaIndicator] == true)
               {
                  comboBox1.Items.Add(subFolder.Name);
               }
            }
            catch (Exception)
            {
            }

         }
         comboBox1.Sorted = true;
      }

      private void button1_Click(object sender, EventArgs e)
      {
         //Validation Routine
         if (!ValidateData())
            return;

         string baseFolderPath = "/" + comboBox1.SelectedItem.ToString() + "/" + comboBox2.SelectedItem.ToString();
         string strFolderPath = baseFolderPath + "/" + textBox1.Text;


         // File the document in a folder
         IFolder folder;
         try
         {
            //try to get the new category
            folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);
         }
         catch (EngineRuntimeException ere)
         {
            ExceptionCode code = ere.GetExceptionCode();
            if (code != ExceptionCode.E_OBJECT_NOT_FOUND)
            {
               throw ere;
            }

            //get the root folder
            IFolder rootFolder = Factory.Folder.FetchInstance(FNStore, baseFolderPath, null);

            //get the root folders class
            IClassDescription rootFolderClassDescription = rootFolder.ClassDescription;
            IClassDefinition rootFolderClass = Factory.ClassDefinition.FetchInstance(FNStore, rootFolderClassDescription.SymbolicName, null);

            //create the subfolder
            folder = rootFolder.CreateSubFolder(textBox1.Text);
            folder.Save(RefreshMode.REFRESH);

            //get the subfolder and update it's class to the new subclass
            folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);
            folder.ChangeClass(rootFolderClass.SymbolicName);
            folder.Save(RefreshMode.NO_REFRESH);
         }

         MessageBox.Show("Document Type created successfully!", "Admin Imaging Create Document Type");
         DialogResult = DialogResult.OK;
         this.Close();
      }

      private bool ValidateData()
      {
         if (string.IsNullOrEmpty(comboBox1.Text))
         {
            MessageBox.Show("Please select a Document Area", "Admin Imaging Create Document Type");
            return false;
         }

         if (string.IsNullOrEmpty(comboBox2.Text))
         {
            MessageBox.Show("Please enter a Document Category", "Admin Imaging Create Document Type");
            return false;
         }

         if (string.IsNullOrEmpty(textBox1.Text))
         {
            MessageBox.Show("Please enter a Document Type", "Admin Imaging Create Document Type");
            return false;
         }

         try
         {
            string baseFolderPath = "/" + comboBox1.SelectedItem.ToString() + "/" + comboBox2.SelectedItem.ToString();
            string strFolderPath = baseFolderPath + "/" + textBox1.Text;

            //try to get the new category
            IFolder folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);

            MessageBox.Show("Document Type already exists. Please enter a new Document Type", "Admin Imaging Create Document Type");
            return false;
         }
         catch (Exception)
         {
         }

         return true;
      }

      private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
      {
         comboBox2.Text = "";

         SetDocumentCategories(comboBox1.Text);
      }

      public void SetDocumentCategories(string stringFolderPath)
      {
         if (string.IsNullOrEmpty(stringFolderPath)) { return; }

         if (comboBox2.Items.Count > 0)
         {
            comboBox2.Items.Clear();
         }

         try
         {
            IFolder folder = Factory.Folder.FetchInstance(FNStore, "/" + stringFolderPath, null);

            foreach (IFolder subFolder in folder.SubFolders)
            {
               comboBox2.Items.Add(subFolder.Name);
            }
            comboBox2.Sorted = true;
         }
         catch (Exception exc)
         {
            MessageBox.Show("Error retrieving document categories. Please exit application and retry.");
         }

      }

      private void button2_Click(object sender, EventArgs e)
      {
         DialogResult = DialogResult.Cancel;
         this.Close();
      }
   }
}
