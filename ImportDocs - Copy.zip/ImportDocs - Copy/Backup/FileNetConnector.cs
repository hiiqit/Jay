﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AdminImaging.CEWS; 
using Microsoft.Web.Services3;
using Microsoft.Web.Services3.Security.Tokens;
using Microsoft.Web.Services3.Security;
using Microsoft.Web.Services3.Design;
using FileNet.Api.Util;
using FileNet.Api.Core;
using log4net; 
namespace AdminImaging
{
    public class FileNetConnector
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(Program));
        public IConnection getConnection()
        {
            UsernameToken token;
            token = new UsernameToken("p8admin","U45y5A9w",PasswordOption.SendPlainText);
            UserContext.SetThreadSecurityToken(token);
            String uri = "http://hct071orsvtd901:9081/wsi/FNCEWS40MTOM";
            IConnection conn = Factory.Connection.GetConnection(uri);
            log.Info("FileNet Connection Established - " + uri);
            return conn; 
        }

        public IDomain getDomain(IConnection conn)
        {
            String domainName = "ORS";
            IDomain domain;
            domain = Factory.Domain.FetchInstance(conn,domainName,null);
            log.Info("FileNet Domain Retrieved - " + domainName);
            return domain; 
        }

        public IObjectStore getObjectStore(IDomain domain)
        {
            String objStoreName = "ORS";
            IObjectStore objStore;
            objStore = Factory.ObjectStore.FetchInstance(domain,objStoreName,null);
            log.Info("FileNet Object Store Retrieved - " + objStoreName);
            return objStore;  
        }

        


    }
}
