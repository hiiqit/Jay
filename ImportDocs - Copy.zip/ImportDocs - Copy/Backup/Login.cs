using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AdminImaging
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!txtWinPassword.Text.Equals(txtWinPassword2.Text))
            {
                MessageBox.Show("Password verification failed, Please enter Password/Verify Password", "Admin Imaging - Password Verification", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.DialogResult = DialogResult.None;
            }
            else
            {
                RegistryWriter rw = new RegistryWriter();
                rw.WriteDefaultLogin(txtWinUserName.Text, txtWinPassword.Text);
                if (rw.VerifyDefaultLoginEntries())
                {
                    MessageBox.Show("User Name " + txtWinUserName.Text + " is now configured for auto login.", "Admin Imaging - Automatic Login Enabled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    StartApp();
                }
                else
                    MessageBox.Show("Invalid UserName/Password. Please retry.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RegistryWriter rw = new RegistryWriter();
            if(!rw.VerifyLoginClearText(txtWinUserName.Text, txtWinPassword.Text))
                MessageBox.Show("Invalid UserName/Password. Please retry.");

            StartApp();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            RegistryWriter rw = new RegistryWriter();
            if (rw.VerifyDefaultLoginEntries())
                StartApp();                                
            else
                this.Show(); 
        }

        private void StartApp()
        {
            this.Hide();  
            frmUploadTool fNew = new frmUploadTool();
            fNew.ShowDialog();
            this.Close(); 
        }
        

        
    }
}