﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;  
using System.Reflection;
using FileNet.Api.Util;
using FileNet.Api.Core;
using FileNet.Api.Constants;
using FileNet.Api.Collection;
using FileNet.Api.Property;

using Microsoft.Office.Interop.Excel;
using log4net;
 
namespace AdminImaging
{
    public partial class frmUploadTool : Form
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(Program));

        FileNetConnector oFileNet = new FileNetConnector();
        IConnection FNConn;
        IDomain FNDomain;
        IObjectStore FNStore;
        System.Data.DataTable dt = new System.Data.DataTable();
        private DateTimePicker picker;
        private ComboBox cmbDocType = new ComboBox();
        private String strCopy_ColValue1 = "";
        private String strCopy_ColValue2 = "";
        private String strCopy_ColValue3 = "";
        private String strCopy_ColValue4 = "";
        private Microsoft.Office.Interop.Excel.ApplicationClass ExcelApp;
        private Int32 iDocSuccessCount = 0;
        private Int32 iDocFailureCount = 0;
        private String DocCategorySelectedText = "";
        private String FolderSelectedText = "";
        private bool _UploadCancelled = false;
         
        public frmUploadTool()
        {
            InitializeComponent();
            InitializeControls();
            InitializeObjects();
            SetDocumentCategories();
        }

        private void InitializeObjects()
        {
            FNConn = oFileNet.getConnection();
            FNDomain = oFileNet.getDomain(FNConn);
            FNStore = oFileNet.getObjectStore(FNDomain);            
        }

        private void InitializeControls()        
        {          
            txtFolder.Text = "";
            SetDataTable();
            prgBar.Visible = false;            
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            statusLabel.Text = "Help: Select the folder that needs to be uploaded.";
            fdrBrowser.ShowDialog();
            txtFolder.Text = fdrBrowser.SelectedPath;
            FolderSelectedText = txtFolder.Text;
            //SetListDetails(); 
        }

        private void SetListDetails()
        {
            try
            {
                log.Info("Folder Selected - " + txtFolder.Text);
                statusLabel.Text = "Files are populated now.";
 
                if (txtFolder.Text == "")
                    return;

                DirectoryInfo oDir = new DirectoryInfo(txtFolder.Text);
                if (oDir.Exists)
                {
                    foreach (FileInfo oFile in oDir.GetFiles())
                    {
                        AddRow(oFile.Name, oFile.Name.Replace(oFile.Extension, ""));
                    }

                    AddHiddenControlstoGrid();
                }
                else
                {
                    MessageBox.Show("Please check your Upload Folder path.", "Admin Imaging - Select Upload Folder", MessageBoxButtons.OK);
                }

                BindingSource oBS = new BindingSource();
                oBS.DataSource = dt;

                dgDetails.DataSource = oBS;
                dgDetails.Refresh();

                log.Info("Files added to the grid - " + dgDetails.RowCount.ToString());
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error occured populating the files. Please exit application and retry.");
                log.Error("Error occured populating the files. Please exit application and retry.", exc);  
            }

        }

        private void SetDataTable()
        {
            // define the table's schema
            dt.Columns.Add(new DataColumn("DocName", typeof(string)));
            dt.Columns.Add(new DataColumn("DocTitle", typeof(string)));
            dt.Columns.Add(new DataColumn("DocType", typeof(string)));
            dt.Columns.Add(new DataColumn("DocDate", typeof(DateTime)));
            dt.Columns.Add(new DataColumn("DocSource", typeof(string)));
            dt.Columns.Add(new DataColumn("DocComments", typeof(string)));            
        }

        private void AddRow(String DocFullName, String DocTitle)
        {
            DataRow dr = dt.NewRow();
            dr["DocName"] = DocFullName;
            dr["DocTitle"] = DocTitle;
            dt.Rows.Add(dr);
        }

        public void SetDocumentCategories()
        {
            try
            {
                String strSymbolicName = "Administration";

                // Fetch selected class definition from the server
                FileNet.Api.Admin.IClassDefinition objClassDef = Factory.ClassDefinition.FetchInstance(FNStore, strSymbolicName, null);

                foreach (FileNet.Api.Admin.IClassDefinition oSubClass in objClassDef.ImmediateSubclassDefinitions)
                {
                    cmbDocCategory.Items.Add(oSubClass.Name);
                }
                cmbDocCategory.Sorted = true;
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error retrieving document categories. Please exit application and retry.");
                log.Error("Error retrieving document categories. Please exit application and retry.",exc); 
            }

        }

        private void SetDocTypes()
        {
            try
            {
                cmbDocType.Items.Clear();

                foreach (FileNet.Api.Admin.IChoiceList RootChoiceList in FNStore.ChoiceLists)
                {
                    if (RootChoiceList.Name.Equals(cmbDocCategory.SelectedItem.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        foreach (FileNet.Api.Admin.IChoice oValuesList in RootChoiceList.ChoiceValues)
                        {
                            cmbDocType.Items.Add(oValuesList.ChoiceStringValue);
                        }
                        break;
                    }
                }
                this.cmbDocType.Sorted = true;
            }
            catch (Exception exc)
            {
                MessageBox.Show("Error retrieving document types. Please exit application and retry.");
                log.Error("Error retrieving document types. Please exit application and retry.", exc);
            }
        }

        private void cmbDocCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            Log("Doc Category Selected - " + cmbDocCategory.Text);
            statusLabel.Text = "Help: Please select the Document Category that needs to be associated for the rows listed.";
  
            if (cmbDocCategory.Text == DocCategorySelectedText)
                return;

            if (dgDetails.RowCount > 0)
            {   
                DialogResult result;
                result = MessageBox.Show("Selecting a different document category now will repopulate the rows below. Do you want to continue?", "Document Category Change", MessageBoxButtons.YesNo);
                Log("Selecting a different document category now will repopulate the rows below. Do you want to continue?");
                if (result == DialogResult.Yes)
                {
                    Log("Yes");
                    ClearDataGridRows();
                }
                else
                {
                    Log("No");
                    cmbDocCategory.Text = DocCategorySelectedText;
                    return;
                }
            }
            DocCategorySelectedText = cmbDocCategory.Text;  
            SetDocTypes();
            Log("Doc Types Set.");

            SetListDetails();
            Log("Grid Populated.");
        }
   

        private void AddHiddenControlstoGrid()
        {  
            this.picker = new DateTimePicker();
            this.picker.Format = DateTimePickerFormat.Short;
            this.picker.Visible = false;
            this.picker.Width = dgDetails.Columns["DocDate"].Width;        
            this.picker.ValueChanged +=new EventHandler(picker_ValueChanged);
            this.dgDetails.Controls.Add(picker);
                        
            this.cmbDocType.Visible = false; 
            this.cmbDocType.Width = dgDetails.Columns["DocType"].Width;
            this.cmbDocType.SelectedIndexChanged += new EventHandler(cmbDocType_SelectedIndexChanged);

            this.dgDetails.Controls.Add(cmbDocType);

            this.dgDetails.CellBeginEdit += new DataGridViewCellCancelEventHandler(dgDetails_CellBeginEdit);
            this.dgDetails.CellEndEdit += new DataGridViewCellEventHandler(dgDetails_CellEndEdit);

            Log("Added hidden controls and events.");
        }
  
        private void picker_ValueChanged(object sender, EventArgs e)
        {
            statusLabel.Text = "Please provide appropriate value for this record.";
            try
            {
                this.dgDetails.CurrentCell.Value = picker.Text;
            }
            catch(Exception){}
        }

        private void cmbDocType_SelectedIndexChanged(object sender, EventArgs e)
        {
            statusLabel.Text = "Please provide appropriate value for this record.";
            try
            {
                this.dgDetails.CurrentCell.Value = cmbDocType.SelectedItem.ToString();
            }
            catch (Exception) { }
        }
 
        private void dgDetails_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            statusLabel.Text = "Please provide appropriate value for this record."; 
            try
            {
                if (this.dgDetails.Focused && this.dgDetails.CurrentCell.ColumnIndex == 3)
                {
                    picker.Location = this.dgDetails.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false).Location;
                    picker.Visible = true;
                    if (this.dgDetails.CurrentCell.Value != null && this.dgDetails.CurrentCell.Value.ToString() != "")
                        picker.Value = (DateTime)this.dgDetails.CurrentCell.Value;
                    else
                        picker.Value = DateTime.Now;//Set today as default date;
                }
                else
                {
                    picker.Visible = false;
                }

                if (this.dgDetails.Focused && this.dgDetails.CurrentCell.ColumnIndex == 2)
                {
                    cmbDocType.Location = this.dgDetails.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false).Location;
                    this.cmbDocType.Visible = true;
                    if (this.dgDetails.CurrentCell.Value != null && this.dgDetails.CurrentCell.Value.ToString() != "")
                        this.cmbDocType.SelectedText = (String)this.dgDetails.CurrentCell.Value;
                    else
                        this.cmbDocType.SelectedText = "";
                }
                else
                {
                    this.cmbDocType.Visible = false;
                }
            }
            catch (Exception){}
        }
 
        private void dgDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                statusLabel.Text = "";
                if (this.dgDetails.Focused && this.dgDetails.CurrentCell.ColumnIndex == 3)
                {
                    this.dgDetails.CurrentCell.Value = picker.Text;
                    picker.Visible = false;
                }
                else if (this.dgDetails.Focused && this.dgDetails.CurrentCell.ColumnIndex == 2)
                {
                    if (this.cmbDocType.SelectedItem != null)
                        this.dgDetails.CurrentCell.Value = this.cmbDocType.SelectedItem.ToString();

                    this.cmbDocType.Visible = false;
                }
                dgDetails.RefreshEdit();
            }
            catch (Exception){}
        }



        private void dgDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (this.dgDetails.Focused && this.dgDetails.CurrentCell.ColumnIndex == 0)
                {
                    if (this.dgDetails.CurrentCell.Value != null)
                        Process.Start(txtFolder.Text + @"\" + this.dgDetails.CurrentCell.Value.ToString());
                }
            }
            catch (Exception){}            
        }

        private void dgDetails_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            try
            {
                if (this.dgDetails.SelectedCells.Count > 0)
                {
                    if (e.KeyCode == Keys.Delete)
                    {
                        NavigateCells_Command("DEL");
                    }
                }
            }
            catch (Exception) { }
        }

        private void SetupExcel(DataGridView datagridview, bool captions)
        {
            try
            {
                ExcelApp = null; 
                ExcelApp = new Microsoft.Office.Interop.Excel.ApplicationClass();
                ExcelApp.Application.Workbooks.Add(Type.Missing);
                ExcelApp.Columns.ColumnWidth = 30;

                ExcelApp.Cells[1, 1] = "File Name";
                ExcelApp.Cells[1, 2] = "Doc Title";
                ExcelApp.Cells[1, 3] = "Doc Type";
                ExcelApp.Cells[1, 4] = "Doc Date";
                ExcelApp.Cells[1, 5] = "Source ID";
                ExcelApp.Cells[1, 6] = "Comments";
                ExcelApp.Cells[1, 7] = "UploadSuccess?";
                ExcelApp.Cells[1, 8] = "DocID";
                ExcelApp.Cells[1, 9] = "Update Date";
                Microsoft.Office.Interop.Excel.Range currentCellCol = ExcelApp.ActiveCell;
                currentCellCol.EntireRow.Font.Bold = true;
                currentCellCol.EntireRow.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                currentCellCol.EntireRow.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);

                log.Info("Excel ready.");
            }
            catch (Exception exc) 
            {
                log.Error("Excel Create Error.", exc);
                MessageBox.Show("Please exit application and retry.");
                _UploadCancelled = true; 
            }
        }

        private void SaveExcel()
        {
            String strExcelFileName = DateTime.Now.ToString().Replace("/", "").Replace(":", "") + ".xls";
            try
            {
                String strFolderPath = @"C:\temp\";
                if (!Directory.Exists(strFolderPath))
                    strFolderPath = @"C:\";
  
                String strTmpExcelFileName = strFolderPath + strExcelFileName;
                ExcelApp.ActiveWorkbook.SaveCopyAs(strTmpExcelFileName);
                ExcelApp.ActiveWorkbook.Saved = true;
                Log("Excel saved under - " + strTmpExcelFileName);
                ExcelApp.Application.Quit();
                ExcelApp.Quit();
                ExcelApp = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();

                SaveLogtoFileNet(strTmpExcelFileName);
            }
            catch (Exception)
            {
                ExcelApp.Application.Quit();
                ExcelApp.Quit();
                ExcelApp = null;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
            finally
            {
                
            }
        }

        private void item1_Click(object sender, EventArgs e)
        {
            CopyCells();
        }

        private void item2_Click(object sender, EventArgs e)
        {
            NavigateCells_Command("PASTE");
        }

        private void CopyCells()
        {
            try
            {
                if (this.dgDetails.Focused)
                {
                    for (int i = 0; i < dgDetails.SelectedCells.Count; i++)
                    {
                        switch (dgDetails.CurrentCell.ColumnIndex)
                        {
                            case 1:
                                strCopy_ColValue1 = this.dgDetails.CurrentCell.Value.ToString();
                                break;
                            case 2:
                                strCopy_ColValue2 = this.dgDetails.CurrentCell.Value.ToString();
                                break;
                            case 3:
                                strCopy_ColValue3 = this.dgDetails.CurrentCell.Value.ToString();
                                break;
                            case 4:
                                strCopy_ColValue4 = this.dgDetails.CurrentCell.Value.ToString();
                                break;
                        }
                    }
                }
            }
            catch (Exception) { } 
        }
        
        private void NavigateCells_Command(String doFunction)
        {
            try
            {
                for (int i = 0; i < dgDetails.SelectedCells.Count; i++)
                {
                    if (doFunction == "DEL")
                        dgDetails.SelectedCells[i].Value = "";
                    else if (doFunction == "PASTE")
                    {
                        switch (dgDetails.CurrentCell.ColumnIndex)
                        {
                            case 1:
                                dgDetails.SelectedCells[i].Value = strCopy_ColValue1;
                                break;
                            case 2:
                                dgDetails.SelectedCells[i].Value = strCopy_ColValue2;
                                break;
                            case 3:
                                dgDetails.SelectedCells[i].Value = strCopy_ColValue3;
                                break;
                            case 4:
                                dgDetails.SelectedCells[i].Value = strCopy_ColValue4;
                                break;
                        }
                    }
                }
            }
            catch (Exception) { } 
        }

        private void EnableProgressBar()
        {
            prgBar.Visible = true;
            prgBar.Value = 0;
            prgBar.Minimum = 0;
            prgBar.Maximum = 100;
            prgBar.Step = Convert.ToInt16(100/(dgDetails.RowCount+1));
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            Log("Upload Process started.");
            
            if (btnUpload.Text == "Cancel Upload")
            {
                _UploadCancelled = true;
                return;
            }
            else
                _UploadCancelled = false;
            
            //Validation Routine
            if (!ValidateData())
                return;

            btnUpload.Text = "Cancel Upload";

            statusLabel.Text = "Setting up Excel Report...";
            SetupExcel(dgDetails, true);

            statusLabel.Text = "Upload Process started now. Please wait...";
            EnableProgressBar();
                       
            PerformUpload();

            SaveExcel();

            #region ProgressBar
            prgBar.PerformStep();
            prgBar.Visible = false;
            #endregion

            statusLabel.Text = "Saving Excel Report...";
            statusLabel.Text = "Excel Report Saved...";

            if (!_UploadCancelled)
            {
                if (iDocFailureCount == 0)
                {
                    MessageBox.Show("All documents are uploaded successfully." + Environment.NewLine +
                                    "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                                    "Failure Documents Count - " + iDocFailureCount.ToString(), "Upload Status", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    log.Info("All documents are uploaded successfully." + Environment.NewLine +
                                    "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                                    "Failure Documents Count - " + iDocFailureCount.ToString());
                }
                else
                {
                    MessageBox.Show("There are some failures during the upload process!" + Environment.NewLine +
                                    "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                                    "Failure Documents Count - " + iDocFailureCount.ToString(), "Upload Status", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    log.Info("There are some failures during the upload process!" + Environment.NewLine +
                                    "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                                    "Failure Documents Count - " + iDocFailureCount.ToString());
                }
            }
            else
            {
                MessageBox.Show("Few documents got uploaded before the upload was cancelled." + Environment.NewLine +
                             "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                             "Failure Documents Count - " + iDocFailureCount.ToString(), "Upload Status", MessageBoxButtons.OK, MessageBoxIcon.Information);

                log.Info("Few documents got uploaded before the upload was cancelled." + Environment.NewLine +
                                "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                                "Failure Documents Count - " + iDocFailureCount.ToString());
            }
                        
            //prgBar.Refresh();            
            btnUpload.Text = "Start Upload";
            statusLabel.Text = "Upload completed.";
            
            Log("Upload Process Completed.");
        }

        private void SaveLogtoFileNet(String strPath)
        {
            // Create a document instance
            IDocument doc = Factory.Document.CreateInstance(FNStore, "Document");
            FileInfo oLogFile = new FileInfo(strPath);

            doc.Properties["DocumentTitle"] = oLogFile.Name;
            doc.MimeType = "application/vnd.ms-excel";
            
            // Specify internal and external files to be added as content.
            Stream internalFile = File.OpenRead(strPath);
            Log("local log file read.");
            // Add content to the Reservation object
            try
            {
                // First, add a ContentTransfer object.
                IContentTransfer ctObject = Factory.ContentTransfer.CreateInstance();
                IContentElementList contentList = Factory.ContentTransfer.CreateList();
                ctObject.SetCaptureSource(internalFile);
                // Add ContentTransfer object to list
                ctObject.ContentType = doc.MimeType;
                ctObject.RetrievalName = oLogFile.Name; 
                contentList.Add(ctObject);

                doc.ContentElements = contentList;
                doc.Save(RefreshMode.REFRESH);
                Log("Content Elements added.");

                doc.Checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
                doc.Save(RefreshMode.NO_REFRESH);
                Log("Doc Checked in.");

                String strFolderPath = "/Admin Imaging/Logs/";

                // File the document in a folder
                IFolder folder = Factory.Folder.GetInstance(FNStore, ClassNames.FOLDER, strFolderPath);
                IReferentialContainmentRelationship rcr = folder.File(doc,
                        AutoUniqueName.AUTO_UNIQUE, oLogFile.Name,
                        DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
                rcr.Save(RefreshMode.NO_REFRESH);
                Log("Doc filed under folder path - " + strFolderPath);                
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
                log.Error("Log File Upload Failed. Please make sure the Excel Log file is uploaded into FileNet by your FileNet Administrator.", exc);                
            }
            finally
            {
                doc = null;
                oLogFile = null;
                internalFile.Close();
                internalFile.Dispose();
            }

        }

        private void PerformUpload()
        {
            bool blnDocSuccess;
            //int percent = 0;
            IDocument doc = null;
            iDocFailureCount = 0;
            iDocSuccessCount = 0;
            TimeSpan ts = new TimeSpan(5, 0, 0); 
            for (int i = 0; i < dgDetails.RowCount; i++)
            {
                if (_UploadCancelled)
                    break;
               
                DataGridViewRow row = dgDetails.Rows[i];

                if (row.ReadOnly)
                    continue; 

                blnDocSuccess = false;
                try
                {
                    #region Update Doc Properties

                    // Create a document instance
                    doc = Factory.Document.CreateInstance(FNStore, cmbDocCategory.Text.Replace(" ",""));

                    // Set document properties
                    switch (System.IO.Path.GetExtension(row.Cells["DocName"].Value.ToString()).ToLower())
                    {
                        case ".pdf":
                            doc.MimeType = "application/pdf";
                            break;
                        case ".tif":
                            doc.MimeType = "application/tif";
                            break;
                        case ".tiff":
                            doc.MimeType = "application/tif";
                            break;
                        case ".doc":
                            doc.MimeType = "application/msword";
                            break;
                        case ".docx":
                            doc.MimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                            break;
                    }
                    Log("Row - " + i.ToString());
                    Log("FilePath - " + txtFolder.Text + @"\" + row.Cells["DocName"].Value.ToString());

                    doc.Properties["DocumentTitle"] = row.Cells["DocTitle"].Value.ToString(); 
                    Log("DocTitle - " + row.Cells["DocTitle"].Value.ToString());

                    doc.Properties["DocumentType"] = row.Cells["DocType"].Value.ToString();
                    Log("DocType - " + row.Cells["DocType"].Value.ToString());

                    if(isDate(row.Cells["DocDate"].Value.ToString()))
                    {
                        doc.Properties["DocumentDate"] = Convert.ToDateTime(row.Cells["DocDate"].Value.ToString());
                        Log("DocDate - " + row.Cells["DocDate"].Value.ToString());
                    }
                    else
                        Log("DocDate - Empty");

                    doc.Properties["SourceID"] = row.Cells["DocSource"].Value.ToString();
                    Log("DocSource - " + row.Cells["DocSource"].Value.ToString());

                    doc.Properties["Comments"] = row.Cells["DocComments"].Value.ToString();
                    Log("DocComments - " + row.Cells["DocComments"].Value.ToString());

                    doc.Save(RefreshMode.NO_REFRESH);

                    #endregion

                    #region UploadDoc

                    // Specify internal and external files to be added as content.
                    Stream internalFile = File.OpenRead(txtFolder.Text + @"\" + row.Cells["DocName"].Value.ToString());
                    Log("local file read.");
                    // Add content to the Reservation object
                    try
                    {
                        // First, add a ContentTransfer object.
                        IContentTransfer ctObject = Factory.ContentTransfer.CreateInstance();
                        IContentElementList contentList = Factory.ContentTransfer.CreateList();
                        ctObject.SetCaptureSource(internalFile);
                        // Add ContentTransfer object to list
                        ctObject.ContentType = doc.MimeType;
                        ctObject.RetrievalName = row.Cells["DocName"].Value.ToString();
                        contentList.Add(ctObject);

                        doc.ContentElements = contentList;
                        doc.Save(RefreshMode.REFRESH);
                        Log("Content Elements added.");

                        doc.Checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
                        doc.Save(RefreshMode.NO_REFRESH);
                        Log("Doc Checked in.");

                        String strFolderPath = "/Admin Imaging/" + cmbDocCategory.Text + "/" + row.Cells["DocType"].Value.ToString();

                        // File the document in a folder
                        IFolder folder = Factory.Folder.GetInstance(FNStore, ClassNames.FOLDER, strFolderPath);
                        IReferentialContainmentRelationship rcr = folder.File(doc,
                                AutoUniqueName.AUTO_UNIQUE, row.Cells["DocTitle"].Value.ToString(),
                                DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
                        rcr.Save(RefreshMode.NO_REFRESH);
                        Log("Doc filed under folder path - " + strFolderPath);

                        blnDocSuccess = true;
                        iDocSuccessCount++;
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                        log.Error("Doc Upload Failed.", exc); 
                        row.DefaultCellStyle.BackColor = Color.Peru;
                        iDocFailureCount++;
                    }

                    #endregion  
                    
                    #region Excel Update

                    row.ReadOnly = true;
                    for (int j = 0; j < row.Cells.Count; j++)
                    {
                        if (row.Cells[j].Value != null)
                            ExcelApp.Cells[i + 2, j + 1] = row.Cells[j].Value.ToString();
                    }

                    //Upload Success Status
                    if (blnDocSuccess)
                    {
                        ExcelApp.Cells[i + 2, row.Cells.Count + 1] = "Yes";
                        ExcelApp.Cells[i + 2, row.Cells.Count + 2] = doc.Id;
                        ExcelApp.Cells[i + 2, row.Cells.Count + 3] = doc.DateCreated - ts;                        
                        row.DefaultCellStyle.BackColor = Color.Wheat;
                    }
                    else
                    {
                        ExcelApp.Cells[i + 2, row.Cells.Count + 1] = "No";                       
                    }

                    ((Range)ExcelApp.Cells[i + 2, 1]).EntireColumn.AutoFit();
                    ((Range)ExcelApp.Cells[i + 2, 2]).EntireColumn.AutoFit();
                    ((Range)ExcelApp.Cells[i + 2, 3]).EntireColumn.AutoFit();
                    ((Range)ExcelApp.Cells[i + 2, 4]).EntireColumn.AutoFit();
                    ((Range)ExcelApp.Cells[i + 2, 5]).EntireColumn.AutoFit();
                    ((Range)ExcelApp.Cells[i + 2, 6]).EntireColumn.AutoFit();
                    ((Range)ExcelApp.Cells[i + 2, 7]).EntireColumn.AutoFit();
                    ((Range)ExcelApp.Cells[i + 2, 8]).EntireColumn.AutoFit();
                    ((Range)ExcelApp.Cells[i + 2, 9]).EntireColumn.AutoFit();
                    Log("Excel row added.");

                    #endregion
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                    log.Error("Doc Upload Failed - please contact FileNet Administrator for further assistance.", exc); 
                    row.DefaultCellStyle.BackColor = Color.Peru;
                }                
                dgDetails.Refresh();  

                #region ProgressBar
                prgBar.PerformStep();
                //percent = (int)(((double)prgBar.Value / (double)prgBar.Maximum) * 100);
                //prgBar.CreateGraphics().DrawString(percent.ToString() + " % ", new System.Drawing.Font("Arial", (float)7.25, FontStyle.Regular), Brushes.Red, new PointF(prgBar.Width / 2 - 10, prgBar.Height / 2 - 7));
                #endregion                
                System.Windows.Forms.Application.DoEvents();
            }            
        }

        private bool ValidateData()
        {
            String strField;
            for (int i = 0; i < dgDetails.RowCount; i++)
            {
                strField = "";
                if (dgDetails.Rows[i].Cells["DocName"].Value.ToString() == "")
                    strField = "DocName";
                else if (dgDetails.Rows[i].Cells["DocTitle"].Value.ToString() == "")
                    strField = "DocTitle";
                else if (dgDetails.Rows[i].Cells["DocType"].Value.ToString() == "")
                    strField = "DocType";                

                if (strField != "")
                {
                    MessageBox.Show("Please fill data for all required fields.");
                    statusLabel.Text = "Please fill data for all required fields.";
                    dgDetails.CurrentCell = dgDetails.Rows[i].Cells[strField];
                    dgDetails.BeginEdit(true);
                    return false;
                }

                if (dgDetails.Rows[i].Cells["DocDate"].Value.ToString() != "")
                {
                    if (isDate(dgDetails.Rows[i].Cells["DocDate"].Value.ToString()) == false)
                    {
                        MessageBox.Show("Please fill in valid value for the date field.");
                        statusLabel.Text = "Please fill in valid value for the date field.";  
                        dgDetails.CurrentCell = dgDetails.Rows[i].Cells["DocDate"];
                        dgDetails.BeginEdit(true);
                        return false;
                    }
                }
            }
            Log("Validation Successful.");
            statusLabel.Text = "Validation completed."; 
            return true;
        }

        private bool isDate(String value)
        {
          DateTime date;
          return DateTime.TryParse(value, out date);
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            statusLabel.Text = "Help: Resetting will clear all the fields in the application.";  
            DialogResult result;
            result = MessageBox.Show("Are you sure you want to reset the fields?", "Reset Fields", MessageBoxButtons.YesNo);
            Log("Are you sure you want to reset the fields?");
            if (result == DialogResult.Yes)
            {
                Log("Yes");
                ResetFields();
            }
        }

        private void ResetFields()
        {
            ClearDataGridRows();
            txtFolder.Text = "";
            cmbDocCategory.Text = "";
            DocCategorySelectedText = "";
            Log("Fields are reset now.");
        }

        private void ClearDataGridRows()
        {
            for (int i = dgDetails.Rows.Count-1; i >= 0; i--)
                dgDetails.Rows.RemoveAt(i);
            Log("Data Grid Rows cleared.");
        }

        private void txtFolder_TextChanged(object sender, EventArgs e)
        {
            statusLabel.Text = "Help: Select/Enter the folder that needs to be uploaded.";  
            if (txtFolder.Text == FolderSelectedText)
                return;

            if (dgDetails.RowCount > 0)
            {
                DialogResult result;
                result = MessageBox.Show("Selecting a different folder now will remove the rows below. Do you want to continue?", "Folder Change", MessageBoxButtons.YesNo);
                Log("Selecting a different folder now will remove the rows below. Do you want to continue?");
                if (result == DialogResult.Yes)
                {
                    Log("Yes");
                    ClearDataGridRows();
                    cmbDocCategory.Text = ""; 
                }
                else
                {
                    Log("No");
                    txtFolder.Text = FolderSelectedText;
                    return;
                }
            }
        }

        private void Log(String strMsg)
        {
            if (log.IsDebugEnabled)
                log.Debug(strMsg); 
        }

        private void frmUploadTool_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if (btnUpload.Text == "Cancel Upload")
                    _UploadCancelled = true; 
            }
        }

        private void cmbDocCategory_MouseClick(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            statusLabel.Text = "Help: Please select the Document Category that needs to be associated for the files to be uploaded.";
        }

        private void txtFolder_MouseHover(object sender, System.EventArgs e)
        {
            statusLabel.Text = "Help: Select/Enter the folder that needs to be uploaded.";  
        }

        private void btnBrowse_MouseHover(object sender, System.EventArgs e)
        {
            statusLabel.Text = "Help: Select the folder that needs to be uploaded.";
        }

        private void btnReset_MouseHover(object sender, System.EventArgs e)
        {
            statusLabel.Text = "Help: Resetting will clear all the fields in the application.";  
        }

        private void btnUpload_MouseHover(object sender, System.EventArgs e)
        {
            statusLabel.Text = "Help: When you click this button, upload process will be started.";
        }

        private void item1_MouseHover(object sender, System.EventArgs e)
        {
            statusLabel.Text = "Help: This action would copy the content from the current cell you are in.";
        }

        private void item2_MouseHover(object sender, System.EventArgs e)
        {
            statusLabel.Text = "Help: This action would paste the content for all the selected cells.";
        }

        private void frmUploadTool_Load(object sender, EventArgs e)
        {
            this.Focus(); 
        }
        
    }
}
