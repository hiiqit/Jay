﻿namespace AdminImaging
{
   partial class DeleteDocuments
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components = null;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.components = new System.ComponentModel.Container();
         System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DeleteDocuments));
         this.treeView1 = new System.Windows.Forms.TreeView();
         this.button1 = new System.Windows.Forms.Button();
         this.imageList1 = new System.Windows.Forms.ImageList(this.components);
         this.SuspendLayout();
         // 
         // treeView1
         // 
         this.treeView1.ImageIndex = 0;
         this.treeView1.ImageList = this.imageList1;
         this.treeView1.Location = new System.Drawing.Point(12, 28);
         this.treeView1.Name = "treeView1";
         this.treeView1.SelectedImageIndex = 0;
         this.treeView1.Size = new System.Drawing.Size(259, 396);
         this.treeView1.TabIndex = 0;
         this.treeView1.AfterCollapse += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterCollapse);
         this.treeView1.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterExpand);
         // 
         // button1
         // 
         this.button1.Location = new System.Drawing.Point(406, 40);
         this.button1.Name = "button1";
         this.button1.Size = new System.Drawing.Size(75, 23);
         this.button1.TabIndex = 1;
         this.button1.Text = "button1";
         this.button1.UseVisualStyleBackColor = true;
         this.button1.Click += new System.EventHandler(this.button1_Click);
         // 
         // imageList1
         // 
         this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
         this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
         this.imageList1.Images.SetKeyName(0, "CLSDFOLD.ICO");
         this.imageList1.Images.SetKeyName(1, "OPENFOLD.ICO");
         this.imageList1.Images.SetKeyName(2, "Document.ICO");
         // 
         // DeleteDocuments
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(523, 436);
         this.Controls.Add(this.button1);
         this.Controls.Add(this.treeView1);
         this.Name = "DeleteDocuments";
         this.Text = "DeleteDocuments";
         this.Load += new System.EventHandler(this.DeleteDocuments_Load);
         this.ResumeLayout(false);

      }

      #endregion

      private System.Windows.Forms.TreeView treeView1;
      private System.Windows.Forms.Button button1;
      private System.Windows.Forms.ImageList imageList1;
   }
}