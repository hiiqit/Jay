﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using FileNet.Api.Core;
using OfficeOpenXml;
using System.IO;
using OfficeOpenXml.Style;
using System.Threading;

namespace AdminImaging
{
   public partial class DeleteDocuments : Form
   {
      private IObjectStore FNStore;
      public DeleteDocuments(IObjectStore fnStore)
      {
         FNStore = fnStore;
         InitializeComponent();
      }

      private void DeleteDocuments_Load(object sender, EventArgs e)
      {
         //build the treeview
         IFolder folder = Factory.Folder.FetchInstance(FNStore, "/", null);
         foreach (IFolder subFolder in folder.SubFolders)
         {
            try
            {
               if ((Boolean)subFolder.Properties[FileNetConstants.DocumentAreaIndicator] == true)
               {
                  var newNode = treeView1.Nodes.Add(subFolder.GetClassName(), subFolder.Name, 0, 1);
                  newNode.Nodes.Add("dummy");
               }
            }
            catch (Exception)
            {
            }
         }
      }

      private void button1_Click(object sender, EventArgs e)
      {
         var excelPackage = new OfficeOpenXml.ExcelPackage();
         ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("DeleteLog");

         worksheet.DefaultColWidth = 30;

         worksheet.Cells[1, 1].Value = "File Name";
         worksheet.Cells[1, 2].Value = "Doc Title";
         worksheet.Cells[1, 3].Value = "Doc Type";
         worksheet.Cells[1, 4].Value = "Doc System";
         worksheet.Cells[1, 5].Value = "Doc Date";
         worksheet.Cells[1, 6].Value = "Source ID";
         worksheet.Cells[1, 7].Value = "Record Series No";
         worksheet.Cells[1, 8].Value = "Comments";
         worksheet.Cells[1, 9].Value = "DocID";
         worksheet.Cells[1, 10].Value = "Deleted By";
         worksheet.Cells[1, 11].Value = "Delete Date";

         ExcelRow firstRow = worksheet.Row(1);
         firstRow.Style.Font.Bold = true;
         firstRow.Style.Font.Color.SetColor(Color.White);
         firstRow.Style.Fill.PatternType = ExcelFillStyle.Solid;
         firstRow.Style.Fill.BackgroundColor.SetColor(Color.Green);

         Int32 i = new Int32();
         i = 2;

         IFolder folder = Factory.Folder.FetchInstance(FNStore, "/" + treeView1.SelectedNode.FullPath.Replace("\\", "/"), null);

         ProcessFolder(worksheet, folder, ref i);

         String strExcelFileName = DateTime.Now.ToString().Replace("/", "").Replace(":", "") + ".xlsx";
         try
         {
            String strFolderPath = @"C:\temp\";
            if (!Directory.Exists(strFolderPath))
               strFolderPath = @"C:\";

            String strTmpExcelFileName = strFolderPath + strExcelFileName;

            excelPackage.SaveAs(new FileInfo(strTmpExcelFileName));
         }
         catch (Exception ex) { }
      }

      private void ProcessFolder(ExcelWorksheet worksheet, IFolder folder, ref Int32 i)
      {
         worksheet.Cells[i, 1].Value = folder.Name;
         worksheet.Cells[i, 2].Value = "";
         worksheet.Cells[i, 3].Value = "";
         worksheet.Cells[i, 4].Value = "";
         worksheet.Cells[i, 5].Value = "";
         worksheet.Cells[i, 6].Value = "";
         worksheet.Cells[i, 7].Value = "";
         worksheet.Cells[i, 8].Value = "";
         worksheet.Cells[i, 9].Value = "";
         worksheet.Cells[i, 10].Value = Program.LoggedInUser;
         worksheet.Cells[i, 11].Value = DateTime.Now.ToString();

         i++;

         foreach (IDocument document in folder.ContainedDocuments)
         {
            worksheet.Cells[i, 1].Value = document.Name;
            worksheet.Cells[i, 2].Value = document.Properties["DocumentTitle"];
            worksheet.Cells[i, 3].Value = document.Properties["DocumentType"];
            worksheet.Cells[i, 4].Value = document.Properties["DocumentSystem"];
            worksheet.Cells[i, 5].Value = document.Properties["DocumentDate"];
            worksheet.Cells[i, 6].Value = document.Properties["SourceID"];
            worksheet.Cells[i, 7].Value = document.Properties["RecordSeriesNo"];
            worksheet.Cells[i, 8].Value = document.Properties["Comments"];
            worksheet.Cells[i, 9].Value = document.Id;
            worksheet.Cells[i, 10].Value = Program.LoggedInUser;
            worksheet.Cells[i, 11].Value = DateTime.Now.ToString();

            i++;
         }

         foreach (IFolder subFolder in folder.SubFolders)
         {
            try
            {
               ProcessFolder(worksheet, subFolder, ref i);
            }
            catch (Exception)
            {
            }
         }
      }

      private void treeView1_AfterExpand(object sender, TreeViewEventArgs e)
      {
         IFolder folder = Factory.Folder.FetchInstance(FNStore, "/" + e.Node.FullPath.Replace("\\", "/"), null);

         if (e.Node.Nodes[0].Text == "dummy")
         {
            e.Node.Nodes.Clear();

            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += new DoWorkEventHandler(LoadSubFoldersDocumentFromFileNet);
            bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(DoneLoadingFromFileNet);

            object[] oArgs = new object[] { e.Node, folder };
            bw.RunWorkerAsync(oArgs);
         }
      }

      private void LoadSubFoldersDocumentFromFileNet(object sender, DoWorkEventArgs e)
      {
         object[] args = e.Argument as object[];
         TreeNode tNodeParent = args[0] as TreeNode;
         IFolder folder = args[1] as IFolder;

         FileNetConnector oFileNet = new FileNetConnector();
         var FNConn = oFileNet.getConnection(Program.LoggedInUser, Program.Password);
         //var FNDomain = oFileNet.getDomain(FNConn);
         //var FNStore = oFileNet.getObjectStore(FNDomain);

         List<TreeNode> nodesToAdd = new List<TreeNode>();
         foreach (IFolder subFolder in folder.SubFolders)
         {
            try
            {
               TreeNode newNode = new TreeNode(subFolder.Name, 0, 1);
               newNode.Nodes.Add("dummy");

               nodesToAdd.Add(newNode);
            }
            catch (Exception)
            {
            }
         }


         foreach (IDocument document in folder.ContainedDocuments)
         {
            nodesToAdd.Add(new TreeNode(document.Name, 2, 2));
         }

         // Return the Parent Tree Node and the list of children to the
         // UI thread.
         e.Result = new object[] { tNodeParent, nodesToAdd };
      }

      private void DoneLoadingFromFileNet(object sender, RunWorkerCompletedEventArgs e)
      {
         // Get the Parent Tree Node and the list of children
         // from the Background Worker Thread
         object[] result = e.Result as object[];
         TreeNode parentNode = result[0] as TreeNode;
         List<TreeNode> subNodes = result[1] as List<TreeNode>;

         parentNode.Nodes.Clear();
         parentNode.Nodes.AddRange(subNodes.ToArray());
      }

      private void treeView1_AfterCollapse(object sender, TreeViewEventArgs e)
      {
         //e.Node.Nodes.Clear();
         //e.Node.Nodes.Add("dummy");
      }
   }
}
