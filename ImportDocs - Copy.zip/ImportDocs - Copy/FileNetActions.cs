﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FileNet.Api.Core;
using FileNet.Api.Constants;
using FileNet.Api.Exception;
using FileNet.Api.Meta;
using FileNet.Api.Admin;
using FileNet.Api.Collection;
using FileNet.Api.Query;

namespace AdminImaging
{
   public static class FileNetActions
   {
      public static void DeleteFolder(IObjectStore FNStore, string rootFolderName, string folderName)
      {
         string baseFolderPath = "/" + rootFolderName;
         string strFolderPath = baseFolderPath + "/" + folderName;

         IFolder folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);

         DeleteFolder(folder);
      }

      private static void DeleteFolder(IFolder folder)
      {
         foreach (IFolder subFolder in folder.SubFolders)
         {
            DeleteFolder(subFolder);
         }

         foreach (IDocument document in folder.ContainedDocuments)
         {
            //log each document, ensure we capture the logged in persons name
         }

         //log the folder we want to delete

         folder.Delete();
      }

      public static IFolder CreateFolder(IObjectStore FNStore, string rootFolderName, string folderName)
      {
         string baseFolderPath = "/" + rootFolderName;
         string strFolderPath = baseFolderPath + "/" + folderName;

         // File the document in a folder
         IFolder folder;
         try
         {
            //try to get the new category
            folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);
         }
         catch (EngineRuntimeException ere)
         {
            ExceptionCode code = ere.GetExceptionCode();
            if (code != ExceptionCode.E_OBJECT_NOT_FOUND)
            {
               throw ere;
            }

            //get the root folder
            IFolder rootFolder = Factory.Folder.FetchInstance(FNStore, baseFolderPath, null);

            //get the root folders class
            IClassDescription rootFolderClassDescription = rootFolder.ClassDescription;
            IClassDefinition rootFolderClass = Factory.ClassDefinition.FetchInstance(FNStore, rootFolderClassDescription.SymbolicName, null);

            //create a new subclass for this folder under the root folders class
            string newSubClassSymbolicName = "fdr" + SanitizeClassName(folderName);
            if (!string.IsNullOrEmpty(rootFolderName))
            {
               newSubClassSymbolicName = rootFolderClass.Name + "_" + SanitizeClassName(folderName);
            }

            if (newSubClassSymbolicName.Length > 64)
            {
               newSubClassSymbolicName = newSubClassSymbolicName.Substring(0, 64);
            }

            IClassDefinition newSubClass = rootFolderClass.CreateSubclass();

            //only add the DAI to the root folders
            if (string.IsNullOrEmpty(rootFolderName))
            {
               //create the property definition for this class and set its value
               IPropertyDefinitionBoolean documentAreaProperty = (IPropertyDefinitionBoolean)CreatePropertyDefinitionForClass(FNStore, FileNetConstants.DocumentAreaIndicator);
               documentAreaProperty.PropertyDefaultBoolean = true;

               //assign it to our folder class
               newSubClass.PropertyDefinitions.Add(documentAreaProperty);
            }

            ILocalizedString localizedDisplayName = Factory.LocalizedString.CreateInstance(FNStore);
            localizedDisplayName.LocalizedText = newSubClassSymbolicName;
            localizedDisplayName.LocaleName = "EN_US";

            ILocalizedStringList localizedStrings = Factory.LocalizedString.CreateList();
            localizedStrings.Add(localizedDisplayName);

            newSubClass.DisplayNames = localizedStrings;
            newSubClass.SymbolicName = newSubClassSymbolicName;
            newSubClass.Save(RefreshMode.REFRESH);

            //create the subfolder
            folder = rootFolder.CreateSubFolder(folderName);

            folder.Save(RefreshMode.REFRESH);

            //get the subfolder and update it's class to the new subclass
            folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);
            folder.ChangeClass(newSubClassSymbolicName);
            folder.Save(RefreshMode.NO_REFRESH);


            //only add the DAI to the root folders
            if (string.IsNullOrEmpty(rootFolderName))
            {
               //create document type for the folder we just created
               CreateDocumentType(FNStore, "Document", folderName);
            }
            else
            {
               CreateDocumentType(FNStore, "Document" + "_" + SanitizeClassName(rootFolderName), folderName);
            }
         }

         return folder;
      }

      private static IClassDefinition CreateDocumentType(IObjectStore FNStore, string rootDocument, string folderName)
      {
         //get the root document class
         IClassDefinition rootDocumentClass = Factory.ClassDefinition.FetchInstance(FNStore, rootDocument, null);

         //create a new subclass for this folder under the document class
         IClassDefinition newDocumentSubClass = rootDocumentClass.CreateSubclass();

         //only add the properties to the root document class
         if (rootDocument == "Document")
         {
            //create and assign the properties for the new document class
            newDocumentSubClass.PropertyDefinitions.Add(CreatePropertyDefinitionForClass(FNStore, "SourceID"));
            newDocumentSubClass.PropertyDefinitions.Add(CreatePropertyDefinitionForClass(FNStore, "RecordSeriesNo"));
            newDocumentSubClass.PropertyDefinitions.Add(CreatePropertyDefinitionForClass(FNStore, "DocumentType"));
            newDocumentSubClass.PropertyDefinitions.Add(CreatePropertyDefinitionForClass(FNStore, "DocumentSystem"));
            newDocumentSubClass.PropertyDefinitions.Add(CreatePropertyDefinitionForClass(FNStore, "DocumentDate"));
            newDocumentSubClass.PropertyDefinitions.Add(CreatePropertyDefinitionForClass(FNStore, "Comments"));
         }

         ILocalizedString localizedDisplayName1 = Factory.LocalizedString.CreateInstance(FNStore);
         localizedDisplayName1.LocalizedText = folderName;
         localizedDisplayName1.LocaleName = "EN_US";

         ILocalizedStringList localizedStrings1 = Factory.LocalizedString.CreateList();
         localizedStrings1.Add(localizedDisplayName1);

         newDocumentSubClass.DisplayNames = localizedStrings1;

         string newSubClassSymbolicName = rootDocumentClass.SymbolicName + "_" + SanitizeClassName(folderName);
         if (newSubClassSymbolicName.Length > 64)
         {
            newSubClassSymbolicName = newSubClassSymbolicName.Substring(0, 64);
         }

         newDocumentSubClass.SymbolicName = newSubClassSymbolicName;
         newDocumentSubClass.Save(RefreshMode.REFRESH);

         return newDocumentSubClass;
      }

      public static string SanitizeClassName(string className)
      {
         if (string.IsNullOrEmpty(className))
         {
            return string.Empty;
         }

         className = new string(className.Where(c => char.IsLetterOrDigit(c)).ToArray());

         return className;
      }

      private static IPropertyDefinition CreatePropertyDefinitionForClass(IObjectStore FNStore, string propertyTemplateSymbolicName)
      {
         //get the document area indicator used to identify our root folders
         var searchSQL = new SearchSQL(string.Format("SELECT This FROM PropertyTemplate WHERE (SymbolicName = '{0}')", propertyTemplateSymbolicName));
         var searchScope = new SearchScope(FNStore);
         var list = searchScope.FetchObjects(searchSQL, null, null, null);

         IPropertyTemplate propertyTemplate = null;
         foreach (var item in list)
         {
            propertyTemplate = item as IPropertyTemplate;
         }

         return propertyTemplate.CreateClassProperty();
      }
   }
}
