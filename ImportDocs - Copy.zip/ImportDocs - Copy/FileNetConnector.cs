﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AdminImaging.CEWS;
using Microsoft.Web.Services3;
using Microsoft.Web.Services3.Security.Tokens;
using Microsoft.Web.Services3.Security;
using Microsoft.Web.Services3.Design;
using FileNet.Api.Util;
using FileNet.Api.Core;
using log4net;
using System.Configuration;

namespace AdminImaging
{
    public class FileNetConnector
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(Program));
        public IConnection getConnection(string username, string password)
        {
            String uri = AdminImaging.Properties.Settings.Default.AdminImaging_FileNet_FNCEWS40Service;
            int IsProduction = AdminImaging.Properties.Settings.Default.IsProduction;
            UsernameToken token;

            if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password) && AdminImaging.Properties.Settings.Default.AdminMode == 0)
            {
                token = new UsernameToken(username, password, PasswordOption.SendPlainText);
            }
            else
            {
                if (IsProduction == 1)
                    token = new UsernameToken("indexingusr", "$indexing321", PasswordOption.SendPlainText);
                else
                    //token = new UsernameToken("P8Admin", "F45y5A9w", PasswordOption.SendPlainText);
                    token = new UsernameToken("SA_orsP8Admin", "rgNmAA9ddcd4bKeJlUzSQeDUE", PasswordOption.SendPlainText);
            }

            UserContext.SetThreadSecurityToken(token);
            IConnection conn = Factory.Connection.GetConnection(uri);
            log.Info("FileNet Connection Established - " + uri);
            return conn;
        }

        public IDomain getDomain(IConnection conn)
        {
            String domainName = "ORS";
            IDomain domain;
            domain = Factory.Domain.FetchInstance(conn, domainName, null);
            log.Info("FileNet Domain Retrieved - " + domainName);
            return domain;
        }

        public IObjectStore getObjectStore(IDomain domain)
        {
            String objStoreName = "ORS";
            IObjectStore objStore;
            objStore = Factory.ObjectStore.FetchInstance(domain, objStoreName, null);
            log.Info("FileNet Object Store Retrieved - " + objStoreName);
            return objStore;
        }




    }
}
