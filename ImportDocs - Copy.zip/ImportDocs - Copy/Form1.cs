﻿using System;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using FileNet.Api.Core;
using FileNet.Api.Util;
using FileNet.Api.Constants;
using FileNet.Api.Collection;
using FileNet.Api.Property;
using FileNet.Api.Admin;
using OfficeOpenXml;
using System.IO;
using OfficeOpenXml.Style;
using System.Threading;
using System.Runtime.InteropServices;

namespace AdminImaging
{
    public partial class Form1 : Form
    {
      private IObjectStore FNStore;
      public Form1(IObjectStore fnStore)
      {
         FNStore = fnStore;
         InitializeComponent();
      }

        //Added for Mime Sniffing

      [DllImport(@"urlmon.dll", CharSet = CharSet.Auto)]
      private extern static System.UInt32 FindMimeFromData(
          System.UInt32 pBC,
          [MarshalAs(UnmanagedType.LPStr)] System.String pwzUrl,
          [MarshalAs(UnmanagedType.LPArray)] byte[] pBuffer,
          System.UInt32 cbSize,
          [MarshalAs(UnmanagedType.LPStr)] System.String pwzMimeProposed,
          System.UInt32 dwMimeFlags,
          out System.UInt32 ppwzMimeOut,
          System.UInt32 dwReserverd
      );

      public static string getMimeFromFile(string filename)
      {
          if (!File.Exists(filename))
              throw new FileNotFoundException(filename + " not found");

          byte[] buffer = new byte[256];
          using (FileStream fs = new FileStream(filename, FileMode.Open))
          {
              if (fs.Length >= 256)
                  fs.Read(buffer, 0, 256);
              else
                  fs.Read(buffer, 0, (int)fs.Length);
          }
          try
          {
              System.UInt32 mimetype;
              FindMimeFromData(0, null, buffer, 256, null, 0, out mimetype, 0);
              System.IntPtr mimeTypePtr = new IntPtr(mimetype);
              string mime = Marshal.PtrToStringUni(mimeTypePtr);
              Marshal.FreeCoTaskMem(mimeTypePtr);
              return mime;
          }
          catch (Exception e)
          {
              return "unknown/unknown";
          }
      }

      public static string getExt(string filename)
      {
          string sExt;

          if (!File.Exists(filename))
              throw new FileNotFoundException(filename + " not found");

          try
          {
              // Set document properties
              switch (Path.GetExtension(filename).ToLower())
              {
                  case ".txt":
                     sExt = "text/plain";
                      break;
                  case ".vsd":
                      sExt = "application/vnd.visio";
                      break;
                  case ".xml":
                      sExt = "application/xml";
                      break;
                  case ".gif":
                      sExt = "image/gif";
                      break;
                  case ".html":
                      sExt = "text/html";
                      break;
                  case ".htm":
                      sExt = "text/html";
                      break;
                  case ".xlsx":
                      sExt = "application/vnd.ms-excel";
                      break;
                  case ".xls":
                      sExt = "application/vnd.ms-excel";
                      break;
                  case ".jpg":
                      sExt = "image/jpg";
                      break;
                  case ".jpeg":
                      sExt = "image/jpeg";
                      break;
                  case ".bmp":
                      sExt = "image/bmp";
                      break;
                  case ".mpp":
                      sExt = "application/vnd.ms-project";
                      break;
                  case ".pdf":
                      sExt = "application/pdf";
                      break;
                  case ".tif":
                      sExt = "image/tiff";
                      break;
                  case ".tiff":
                      sExt = "image/tiff";
                      break;
                  case ".rtf":
                      sExt = "application/msword";
                      break;
                  case ".doc":
                      sExt = "application/msword";
                      break;
                  case ".docx":
                      sExt = "application/msword";
                      break;
                  case ".lsx":
                      sExt = "video/x-la-asf";
                      break;
                  case ".ocx":
                      sExt = "application/octet-stream";
                      break;
                  default: throw new FileNotFoundException(filename + " not found");
              }
              return sExt;  
          }
          catch (Exception e)
          {
              return "unknown/unknown"; 
          }
              
      }
        //Mime sniffing end

      //
      // Reads the content from Document's ContentStream and copies it
      // to a file on a file system.
      //
      public static void WriteContentToFile(IContentTransfer ct2, String path)
      {

          //String fileName = doc.Name;
         // String file = Path.Combine(path, fileName);
          try
          {
              FileStream fs = new FileStream(path, FileMode.CreateNew);
              BinaryWriter bw = new BinaryWriter(fs);
              Stream s = ct2.AccessContentStream();   //   AccessContentStream(0);
              byte[] data = new byte[s.Length];
              s.Read(data, 0, data.Length);
              s.Close();
              bw.Write(data);
              bw.Close();
              fs.Close();
          }
          catch (Exception e)
          {
              System.Console.WriteLine(e.StackTrace);
          }
      }

        private void button1_Click(object sender, EventArgs e)
        {
            int counter = 0;
            string line;

            // Read the file and display it line by line.
            System.IO.StreamReader file =
               new System.IO.StreamReader("c:\\FernDocs\\MultiPageStitched.txt");
            while ((line = file.ReadLine()) != null)
            {


                
                
                
                
                
                
                // Get document.
                IDocument doc = Factory.Document.GetInstance (FNStore, ClassNames.DOCUMENT, new Id(line));
             //   PropertyFilter pf = new PropertyFilter();
               // pf.AddIncludeProperty(new FilterElement(null, null, null, "DocumentTitle", null));

           //     IDocument doc = Factory.Document.FetchInstance(FNStore, new Id(line), pf);

                // Check out the Document object and save it.
               // doc.Checkout(ReservationType.EXCLUSIVE, null, doc.GetClassName(), doc.Properties);
                doc.Checkout(ReservationType.EXCLUSIVE, null, null, null);
                doc.Save(RefreshMode.REFRESH);

                // obtain the reservation object (new version in progress)
                IDocument newVersion = (IDocument) doc.Reservation;

                // Add content to reservation document.
                Stream fileStream = File.OpenRead(@"C:\\FernDocs\\Temp\\" + line + ".tif");

                // Create ContentTransfer object.

               // ContentElementList contentElements = Factory.ContentElement.createList();

                IContentTransfer ctObject = Factory.ContentTransfer.CreateInstance();
                IContentElementList contentList = Factory.ContentTransfer.CreateList();
                ctObject.SetCaptureSource(fileStream);
                ctObject.ContentType = "image/tiff";// Must be set for ContentReference.
               
                    // Add ContentTransfer object to list and set on reservation
                contentList.Add(ctObject);
                newVersion.ContentElements = contentList;

                // Check in reservation object as major version.
                newVersion.Checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION  );
                newVersion.Save(RefreshMode.REFRESH);
                doc.SetUpdateSequenceNumber(null);
                doc.CancelCheckout();
                doc.Save(RefreshMode.REFRESH); 
               
             
               
               



              //  doc.CancelCheckout();
              //  doc.Delete();
               // doc.Save(RefreshMode.NO_REFRESH);
                //doc.Save(RefreshMode.REFRESH);
               // doc.Save(RefreshMode.REFRESH);
               // doc.Refresh();
               // newVersion.VersionStatus 
              
              
                
               
               // doc.Save(RefreshMode.REFRESH);
                

                Console.WriteLine(line);
                counter++;
                line = "";
            }

            file.Close();

            // Suspend the screen.
            Console.ReadLine();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int counter = 0;
            string line;
            string TITLE;
            string DOCDESC;
            string DOCSTATUS;
            string DOCINDICATOR;
            string PRE;
            string Datafile;
            string RAILNO;
            string[] csvLine;
            DateTime datVal = DateTime.Now; 

            // Read the file and display it line by line.
            System.IO.StreamReader file = new System.IO.StreamReader("c:\\ECM\\MigrationListLog.txt");
            //System.IO.StreamWriter wMetadataFile = new System.IO.StreamWriter(@fileTextBox.Text + "\\" + "metadata.csv");
            System.IO.StreamWriter dataFile = new System.IO.StreamWriter("C:\\temp\\" + datVal.ToString("yyyyMMddHHmmssffff") + ".txt");
     

            while ((line = file.ReadLine()) != null)
            {


                line = line.Trim();
                csvLine = line.Split(',');   //split line with "|" delimiter

                // Get document.
               // IDocument doc = Factory.Document.GetInstance(FNStore, ClassNames.DOCUMENT, new Id(csvLine[0].Trim ()));

                // Get the storage area where you want to move the document content.

                // IStorageArea sa = Factory.StorageArea.GetInstance(FNStore, new Id("{{6014F40D-6B76-448C-B8DB-883002DCB101}}"));
                IFixedStorageArea sa = Factory.FixedStorageArea.FetchInstance(FNStore, new Id("{6014F40D-6B76-448C-B8DB-883002DCB101}"), null);
                IDocument doc = Factory.Document.GetInstance(FNStore, ClassNames.DOCUMENT, new Id(line));

                IStoragePolicy sp = Factory.StoragePolicy.GetInstance(FNStore, new Id("{6CDC46BD-403D-4B2A-A3F9-308549C685E7}"));
                



                doc.MoveContent(sa);
                doc.StoragePolicy = sp;
                doc.Save(RefreshMode.REFRESH);

               // IDatabaseStorageArea dsa = Factory.FixedStorageArea.FetchInstance(FNStore, new Id("{6014F40D-6B76-448C-B8DB-883002DCB101}"), null);




                doc.FetchProperties(new PropertyFilter());
               

                IProperty propTitle = doc.Properties.GetProperty("DocumentTitle");
                TITLE = propTitle.GetStringValue();
                IProperty propDESC = doc.Properties.GetProperty("DocDescription");
                DOCDESC  = propDESC.GetStringValue();
                IProperty propSTA = doc.Properties.GetProperty("DocumentStatus");
                DOCSTATUS = propSTA.GetStringValue();
                IProperty propINDI = doc.Properties.GetProperty("PermanentDocIndicator");
                DOCINDICATOR = propINDI.GetStringValue();
                IProperty propPRE = doc.Properties.GetProperty("Pre1900");
                PRE = propPRE.GetStringValue();
                IProperty propRAILNO = doc.Properties.GetProperty("RailroadNumber");
                RAILNO = propRAILNO.GetStringValue();

                Datafile = "C:\\FernDocs\\Temp\\" + csvLine[0].Trim () + ".tif";

                 FileInfo oLogFile = new FileInfo(Datafile);

                //IDocument docToInsert = .   CreateDocument(true, Datafile,  "image/tiff", title, os, className);

                
                    IDocument docToInsert = Factory.Document.CreateInstance(FNStore, "RailroadCrossing");
                //    docToInsert.FetchProperties(new PropertyFilter());

                    if (string.IsNullOrEmpty(TITLE) != true )
                        docToInsert.Properties["DocumentTitle"] = TITLE;
                    if (string.IsNullOrEmpty(DOCDESC) != true)
                        docToInsert.Properties["DocDescription"] = DOCDESC;
                    if (string.IsNullOrEmpty(DOCSTATUS) != true)
                        docToInsert.Properties["DocumentStatus"] = DOCSTATUS;
                    if (string.IsNullOrEmpty(DOCINDICATOR) != true)
                        docToInsert.Properties["PermanentDocIndicator"] = DOCINDICATOR;
                    if (string.IsNullOrEmpty(PRE) != true)
                        docToInsert.Properties["Pre1900"] = PRE;
                    if (string.IsNullOrEmpty(RAILNO) != true)
                        docToInsert.Properties["RailroadNumber"] = RAILNO;

                    IProperty propInventory = doc.Properties.GetProperty("NationalInventoryNo");
                   // IProperty propInventory2 = docToInsert.Properties.GetProperty("NationalInventoryNo");
                    

                    IStringList isl = Factory.StringList.CreateList();
                    isl = propInventory.GetStringListValue();

                    //docToInsert.Properties["NationalInventoryNo"] = propInventory;
                    docToInsert.Properties["NationalInventoryNo"] = isl;
                    docToInsert.MimeType = "image/tiff";

                 Stream internalFile = File.OpenRead(Datafile);
                
                 // Add content to the Reservation object
                 try
                 {

                    // First, add a ContentTransfer object.
                    IContentTransfer ctObject = Factory.ContentTransfer.CreateInstance();
                    IContentElementList contentList = Factory.ContentTransfer.CreateList();
                    ctObject.SetCaptureSource(internalFile);
                    // Add ContentTransfer object to list
                    ctObject.ContentType =  docToInsert.MimeType;
                    ctObject.RetrievalName = oLogFile.Name;
                    contentList.Add(ctObject);

                    docToInsert.ContentElements = contentList;
                    docToInsert.Save(RefreshMode.REFRESH);
                    dataFile.WriteLine(csvLine[0] + "-->" + docToInsert.Id.ToString());
                    dataFile.Flush();

                    docToInsert.Checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
                    docToInsert.Save(RefreshMode.NO_REFRESH);

                    String strFolderPath = csvLine[3].Trim ();

                    // File the document in a folder
                    IFolder folder = Factory.Folder.GetInstance(FNStore, ClassNames.FOLDER, strFolderPath);
                    IReferentialContainmentRelationship rcr = folder.File(docToInsert,
                            AutoUniqueName.AUTO_UNIQUE, oLogFile.Name,
                            DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
                    rcr.Save(RefreshMode.NO_REFRESH);
                    
                 }
                 catch (Exception exc)
                 {
                     MessageBox.Show(exc.Message);
                     MessageBox.Show(exc.Message.ToString());
                    
                 }
                 finally
                 {
                     doc = null;
                     docToInsert = null;
                     
                     internalFile.Close();
                     internalFile.Dispose();
                 }
                
                Console.WriteLine(line);
                counter++;
                line = "";
            }

            file.Close();
            dataFile.Close();
            // Suspend the screen.
            Console.ReadLine();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int counter = 0;
            string line;
          
            DateTime datVal = DateTime.Now;

            // Read the file and display it line by line.
            System.IO.StreamReader file = new System.IO.StreamReader("c:\\ECM\\DocMigration\\Disk1.gsd");
            //System.IO.StreamWriter wMetadataFile = new System.IO.StreamWriter(@fileTextBox.Text + "\\" + "metadata.csv");
            System.IO.StreamWriter dataFile = new System.IO.StreamWriter("C:\\ECM\\DocMigration\\LOGS\\" + datVal.ToString("yyyyMMddHHmmssffff") + ".txt");
            dataFile.WriteLine(datVal.ToString("yyyyMMddHHmmssffff"));

            
            // Get the storage area where you want to move the document content
            IFixedStorageArea sa = Factory.FixedStorageArea.FetchInstance(FNStore, new Id("{6014F40D-6B76-448C-B8DB-883002DCB101}"), null);
            IStoragePolicy sp = Factory.StoragePolicy.GetInstance(FNStore, new Id("{6CDC46BD-403D-4B2A-A3F9-308549C685E7}"));
            
            while ((line = file.ReadLine()) != null)
            {

                line = line.Trim();

                // Get document.                                                
                IDocument doc = Factory.Document.GetInstance(FNStore, ClassNames.DOCUMENT, new Id(line));

                // Add content to the Reservation object
                try
                {
                    doc.MoveContent(sa);
                    doc.StoragePolicy = sp;
                    doc.Save(RefreshMode.REFRESH);
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                    MessageBox.Show(exc.Message.ToString());

                }
                finally
                {
                    doc = null;
                }

                countLabel.Text = counter.ToString();
                countLabel.Refresh();
                dataFile.WriteLine(line);
                Console.WriteLine(line);
                counter++;
                line = "";
                //Sleep .2 secp
                Thread.Sleep(200);
                this.Refresh ();
            }

            file.Close();
            dataFile.WriteLine(DateTime.Now.ToString("yyyyMMddHHmmssffff"));
            dataFile.Close();
            // Suspend the screen.
            Console.ReadLine();
        }
        /*
        private void button4_Click(object sender, EventArgs e)
        {
            int counter = 0;
            string line;
            String fname;
            String rtName;


            DateTime datVal = DateTime.Now;

            // Read the file and display it line by line.
          //  System.IO.StreamReader file = new System.IO.StreamReader("C:\\Temp\\DOCIDLISTUAT.txt");
            System.IO.StreamReader file = new System.IO.StreamReader("H:\\MEMBERLIST\\Disk2.gsd");
            //System.IO.StreamWriter wMetadataFile = new System.IO.StreamWriter(@fileTextBox.Text + "\\" + "metadata.csv");
            System.IO.StreamWriter dataFile = new System.IO.StreamWriter("H:\\Temp\\DocMigration\\LOGS\\" + datVal.ToString("yyyyMMddHHmmssffff") + ".txt");
            dataFile.WriteLine(datVal.ToString("yyyyMMddHHmmssffff"));
            dataFile.Flush();
            

            while ((line = file.ReadLine()) != null)
            {

                line = line.Trim();

                // Get document.                                                
                IDocument doc = Factory.Document.GetInstance(FNStore, ClassNames.DOCUMENT, new Id(line.Substring (0,38)));
                doc.FetchProperties(new PropertyFilter());
                //IProperty Mime = doc.Properties.GetProperty("MimeType");
               // MessageBox.Show(Mime.ToString());

                IContentElementList docContentList = doc.ContentElements;
                System.Collections.IEnumerator iter = docContentList.GetEnumerator();

                int i = 1;
                while (iter.MoveNext())
                {

                   
                    IContentTransfer ct = (IContentTransfer)iter.Current;
                    
                    rtName = ct.RetrievalName.ToString().Trim();
                    //MessageBox.Show(ct.ContentType.ToString());
                    fname = "H:\\Temp\\DocMigration\\Content\\" + line.Substring(0, 38) + "_" + i.ToString() + "_" + rtName;
                   
                    try
                    {
                        WriteContentToFile(ct, fname);
                       
                        //MessageBox.Show(getMimeFromFile(fname));
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                        MessageBox.Show(exc.Message.ToString());

                    }
                    finally
                    {
                        doc = null;

                    }
                    i++;
                    fname = "";
                    rtName = "";
                }

                countLabel.Text = counter.ToString();
                countLabel.Refresh();
                counter++;
                dataFile.WriteLine(line + "|" + docContentList.Count +  "|" + "Disk2.gsd" );
                dataFile.Flush();
                line = "";
                fname = "";
                rtName = "";
                //Sleep .2 secp
                Thread.Sleep(300);
                
                this.Refresh();
                doc = null;
                docContentList = null;
            }

            file.Close();
            dataFile.WriteLine(DateTime.Now.ToString("yyyyMMddHHmmssffff"));
            dataFile.Flush();
            dataFile.Close();
            // Suspend the screen.
            Console.ReadLine();

        }
        */
        //scanneddate|u63_scannedby|u64_receiveddate|u65_processid|u66_plan|u67_microreelnumber|u68_microimagenumber|u69_indexedby|u6a_indexdate|u6b_employernumber|u6c_docname|u6d_doccategory|u6e_batchid|u6f_ssn|u70_f_archivedate|u71_f_deletedate|u72_f_docnumber|u73_f_entrydate|u74_comments|u75_documentsystem|u76_documenttype|u77_documentdate|u78_sourceid|u79_recordseriesno|u7a_terminaldigitsort
        private void button4_Click(object sender, EventArgs e)
        {
            int counter = 0;
            string line;
            String fname;
            String rtName;
            string GUID;


            DateTime datVal = DateTime.Now;

            // Read the file and display it line by line.
            //  System.IO.StreamReader file = new System.IO.StreamReader("C:\\Temp\\DOCIDLISTUAT.txt");
            System.IO.StreamReader file = new System.IO.StreamReader("C:\\Documents and Settings\\$khatrij\\My Documents\\MEMBERLIST\\Disk4.gsd");
            //System.IO.StreamWriter wMetadataFile = new System.IO.StreamWriter(@fileTextBox.Text + "\\" + "metadata.csv");
            System.IO.StreamWriter dataFile = new System.IO.StreamWriter("I:\\Temp\\DocMigration\\LOGS\\" + datVal.ToString("yyyyMMddHHmmssffff") + ".txt");
            dataFile.WriteLine(datVal.ToString("yyyyMMddHHmmssffff"));
            dataFile.Flush();


            while ((line = file.ReadLine()) != null)
            {

                line = line.Trim();

                GUID = line.Substring(0, 38);

                // Get document.                                                
                IDocument doc = Factory.Document.GetInstance(FNStore, ClassNames.DOCUMENT, new Id(GUID));
                doc.FetchProperties(new PropertyFilter());
                //IProperty Mime = doc.Properties.GetProperty("MimeType");
                // MessageBox.Show(Mime.ToString());

                IContentElementList docContentList = doc.ContentElements;
                System.Collections.IEnumerator iter = docContentList.GetEnumerator();

                int i = 1;
                while (iter.MoveNext())
                {


                    IContentTransfer ct = (IContentTransfer)iter.Current;

                    rtName = ct.RetrievalName.ToString().Trim();
                    //MessageBox.Show(ct.ContentType.ToString());

                    if (!Directory.Exists("I:\\Temp\\DocMigration\\Content\\" + GUID))
                    {
                        DirectoryInfo di = Directory.CreateDirectory("I:\\Temp\\DocMigration\\Content" + "\\" + GUID);
                        fname = "I:\\Temp\\DocMigration\\Content\\" + GUID + "\\" + GUID + "_" + i.ToString() + "_" + rtName;
                    }
                    else
                    {
                        fname = "I:\\Temp\\DocMigration\\Content\\" + GUID + "\\" + GUID + "_" + i.ToString() + "_" + rtName;
                    }
                    //    fname = "H:\\Temp\\DocMigration\\Content\\" + line.Substring(0, 38) + "_" + i.ToString() + "_" + rtName;

                    try
                    {
                        WriteContentToFile(ct, fname);

                        //MessageBox.Show(getMimeFromFile(fname));
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                        MessageBox.Show(exc.Message.ToString());

                    }
                    finally
                    {
                        doc = null;

                    }
                    i++;
                    fname = "";
                    rtName = "";
                }

                countLabel.Text = counter.ToString();
                countLabel.Refresh();
                counter++;
                dataFile.WriteLine(line + "|" + docContentList.Count + "|" + "Disk4.gsd");
                dataFile.Flush();
                line = "";
                fname = "";
                rtName = "";
                GUID = "";
                //Sleep .2 secp
                //Thread.Sleep(300);

                this.Refresh();
                doc = null;
                docContentList = null;
            }

            file.Close();
            dataFile.WriteLine(DateTime.Now.ToString("yyyyMMddHHmmssffff"));
            dataFile.Flush();
            dataFile.Close();
            // Suspend the screen.
            Console.ReadLine();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            

            int counter = 0;
            string GUID;
            int Pages;
            string line;
            string FileP;

            string TITLE;
            string name_;
            string scanneddate;
            string scannedby;
            string receiveddate;
            string processid;
            string plan;
            string microreelnumber;
            string microimagenumber;
            string indexedby;
            string indexdate;
            string employernumber;
            string docname;
            string doccategory;
            string batchid;
            string ssn;
            string f_archivedate;
            string f_deletedate;
            string f_docnumber;
            string f_entrydate;
            String FILENAME;

            string[] csvLine;
           
            DateTime datVal = DateTime.Now;

            // Read the file and display it line by line.
            //System.IO.StreamReader file = new System.IO.StreamReader("H:\\Temp\\DocMigration\\LOGS\\201808221627510590.txt");
            System.IO.StreamReader file = new System.IO.StreamReader("C:\\Temp\\IMPORTTOFILENET\\XLSTIFF2022.csv");
          
            //System.IO.StreamWriter wMetadataFile = new System.IO.StreamWriter(@fileTextBox.Text + "\\" + "metadata.csv");
            System.IO.StreamWriter dataFile = new System.IO.StreamWriter("C:\\Temp\\IMPORTTOFILENET\\" + datVal.ToString("yyyyMMddHHmmssffff") + ".txt");


            while ((line = file.ReadLine()) != null)
            {

                line = line.Trim();
                csvLine = line.Split(',');   //split line with "|" delimiter
                
                GUID = csvLine[0].Trim();
                name_ = csvLine[2].Trim();
              
                ssn = csvLine[3].Trim();
                scanneddate = csvLine[4].Trim();  // string val = DateTime.UtcNow.ToString("yyyy-MM-dd-hh:mm:ss.ffffff");
                scannedby = csvLine[5].Trim();
                processid = csvLine[6].Trim();
                plan = csvLine[7].Trim();
                microreelnumber = csvLine[8].Trim();
                microimagenumber = csvLine[9].Trim();
                receiveddate = csvLine[10].Trim();
                indexdate = csvLine[11].Trim();
                indexedby = csvLine[12].Trim();
                docname = csvLine[13].Trim();
                doccategory = csvLine[14].Trim();
                batchid = csvLine[16].Trim();
                FILENAME = csvLine[17].Trim();

                Pages = 1;
                TITLE = docname;
             
                IDocument docToInsert = Factory.Document.CreateInstance(FNStore, "Member");
              //  docToInsert.FetchProperties(new PropertyFilter());


              
                if (string.IsNullOrEmpty(TITLE) != true)
                    docToInsert.Properties["DocumentTitle"] = TITLE;
                if (string.IsNullOrEmpty(name_) != true)
                    docToInsert.Properties["name_"] = name_;
                if (string.IsNullOrEmpty(ssn) != true)
                    docToInsert.Properties["ssn"] = ssn;
                if (string.IsNullOrEmpty(docname) != true)
                    docToInsert.Properties["docname"] = docname;
                if (string.IsNullOrEmpty(doccategory) != true)
                    docToInsert.Properties["doccategory"] = doccategory;
                if (string.IsNullOrEmpty(microreelnumber) != true)
                    docToInsert.Properties["microreelnumber"] = microreelnumber;
                if (string.IsNullOrEmpty(microimagenumber) != true)
                    docToInsert.Properties["microimagenumber"] = microimagenumber;
                if (string.IsNullOrEmpty(indexedby) != true)
                    docToInsert.Properties["indexedby"] = indexedby;
                if (string.IsNullOrEmpty(plan) != true)
                    docToInsert.Properties["plan"] = plan;
                if (string.IsNullOrEmpty(batchid) != true)
                    docToInsert.Properties["batchid"] = batchid;
                if (string.IsNullOrEmpty(processid) != true)
                    docToInsert.Properties["processid"] = processid;
            
                if (string.IsNullOrEmpty(scannedby) != true)
                    docToInsert.Properties["scannedby"] = scannedby;

                if (string.IsNullOrEmpty(indexdate) != true)
                    docToInsert.Properties["indexdate"] = DateTime.ParseExact(indexdate, "yyyy-MM-dd HH:mm:ss",
                                       System.Globalization.CultureInfo.InvariantCulture); ;
                if (string.IsNullOrEmpty(receiveddate) != true)
                    docToInsert.Properties["receiveddate"] = DateTime.ParseExact(receiveddate, "yyyy-MM-dd HH:mm:ss",
                                       System.Globalization.CultureInfo.InvariantCulture); ;
                if (string.IsNullOrEmpty(scanneddate) != true)
                    docToInsert.Properties["scanneddate"] = DateTime.ParseExact(scanneddate, "yyyy-MM-dd HH:mm:ss",
                                        System.Globalization.CultureInfo.InvariantCulture); ;

                FileP = @"D:\Temp\DocMigration\Content" + "\\" + FILENAME;
              
                IContentElementList contentList = Factory.ContentTransfer.CreateList();
             

                for (int i = 1; i <=Pages; i++)
                {
                    string s = GUID + "_" + i + "_*";
                    string[] files1 = Directory.GetFiles(FileP, s);
                   // sExt = Path.GetExtension(files1[0]).ToLower();
                    IContentTransfer ctObject = Factory.ContentTransfer.CreateInstance();

                    try
                    {
                        // Add content to reservation document.
                        //Stream fileStream = File.OpenRead(FileP + "\\" + files1[0]);   
                        Stream fileStream = File.OpenRead(files1[0]);
                        ctObject.SetCaptureSource(fileStream);
                        ctObject.ContentType = getExt (files1[0]);
                        ctObject.RetrievalName = Path.GetFileName(files1[0]);
                        contentList.Add(ctObject);
                        //MessageBox.Show(contentList.Count.ToString());
                       
                    }
                    catch (Exception exc)
                    {
                        MessageBox.Show(exc.Message);
                        MessageBox.Show(exc.Message.ToString());

                    }
                    finally
                    {
                        s = "";
                        files1 = null;
                        ctObject = null;
                    }
                }

                try
                {
                    docToInsert.ContentElements = contentList;
                    docToInsert.Checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
                    docToInsert.Save(RefreshMode.REFRESH);
                    dataFile.WriteLine(csvLine[0] + "-->" + docToInsert.Id.ToString ());
                    dataFile.Flush();
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                    MessageBox.Show(exc.Message.ToString());

                }
                finally
                {
                    docToInsert = null;
                    contentList = null;

                  

                    //Delete files and folder
                   // string[] di = Directory.GetFiles ("H:\\Temp\\DocMigration\\Content\\" +  GUID);
                   // foreach (string f in di)
                   // {
                   //     File.Delete(f);
                   // }
                  //  if (Directory.Exists("H:\\Temp\\DocMigration\\Content\\" + GUID))
                  //  {
                  //      Directory.Delete(("H:\\Temp\\DocMigration\\Content\\" + GUID), true);
                  //  }
                   // di = null; 
                }

                Application.DoEvents();
                line = "";
                GUID = "";
                TITLE = "";
                name_ = "";
                scanneddate = "";
                scannedby = "";
                receiveddate = "";
                processid = "";
                plan = "";
                microreelnumber = "";
                microimagenumber = "";
                indexedby = "";
                indexdate = "";
                employernumber = "";
                docname = "";
                doccategory = "";
                batchid = "";
                ssn = "";
                f_archivedate = "";
                f_deletedate = "";
                f_docnumber = "";
                f_entrydate = "";
                csvLine = null;
                

                countLabel.Text = counter.ToString();
                countLabel.Refresh();
                this.Refresh();
                counter++;
            }

            file.Close();
            dataFile.Close();
            // Suspend the screen.
            Console.ReadLine();
            
        }

        private void button3_Click_1(object sender, EventArgs e)
        {

            DateTime datVal = DateTime.Now;
            string line;
            string[] csvLine;
            string GUID;
            int PAGES;
            string path;
            int counter = 0;
            string p1;
            string p2;

            // Read the file and display it line by line.
            System.IO.StreamReader file = new System.IO.StreamReader("G:\\Disk2Combined_PAGES.txt");
            //System.IO.StreamWriter wMetadataFile = new System.IO.StreamWriter(@fileTextBox.Text + "\\" + "metadata.csv");
            System.IO.StreamWriter dataFile = new System.IO.StreamWriter("C:\\temp\\" + datVal.ToString("yyyyMMddHHmmssffff") + ".txt");

           

          
              //  line = line.Trim();
              //  csvLine = line.Split('|');   //split line with "|" delimiter

            //    GUID = csvLine[0].Trim();
            //    PAGES = int.Parse(csvLine[1].Trim());

               // path = "H:\\Temp\\DocMigration\\Content\\"; // +GUID;
                path = @"H:\Temp\DocMigration\Content\"; // +GUID;

                string[] files1 = Directory.GetFiles(path);

                Array.Sort(files1);


                foreach (string  f in  files1)
                {
                    String FName = Path.GetFileName(f);

                    GUID = FName.Substring(0, 37);

                    try
                    {
                        if (!Directory.Exists(path + "\\" + GUID))
                        {
                            // Try to create the directory.
                            DirectoryInfo di = Directory.CreateDirectory(path + "\\" + GUID);
                            p1 = path + FName ;
                            p2 = path + GUID + "\\" + FName;

                            File.Move(p1, p2);
                        }
                        else
                        {
                            p1 = path + FName ;
                            p2 = path + GUID + "\\" + FName;

                            File.Move(p1, p2);
                        }
                    }
                    catch (IOException ioex)
                    {
                        Console.WriteLine(ioex.Message);
                        MessageBox.Show(ioex.Message);
                        MessageBox.Show(ioex.Message.ToString());
                    }
                    GUID = "";
                    FName = "";
                    p1 = "";
                    p2 = "";
                    counter++;
                    countLabel.Text = counter.ToString();
                    countLabel.Refresh();
                    this.Refresh();
                }

             
                  
                line = "";
                csvLine = null;
               // files1 = null;


                /*

                try
                {
                    if (!Directory.Exists(path))
                    {
                        // Try to create the directory.
                        DirectoryInfo di = Directory.CreateDirectory(path);
                    }
                }
                catch (IOException ioex)
                {
                    Console.WriteLine(ioex.Message);
                    MessageBox.Show(ioex.Message);
                    MessageBox.Show(ioex.Message.ToString());
                }
                */
                counter++;
                countLabel.Text = counter.ToString();
                countLabel.Refresh();
                this.Refresh();
                
           


        }
           

    }
}
