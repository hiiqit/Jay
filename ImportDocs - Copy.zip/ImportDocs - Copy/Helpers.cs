﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace AdminImaging
{
   public static class Helpers
   {
      public static string ComputeTerminalDigitSort(string name)
      {
         string terminalDigitSort = "";

         //Finish File
         if (Regex.IsMatch(name, @"^\d{4}_\d{4}-\d{4}$"))
         {
            terminalDigitSort += name[7];
            terminalDigitSort += name[8];
            terminalDigitSort += name[5];
            terminalDigitSort += name[6];

            terminalDigitSort += name[12];
            terminalDigitSort += name[13];
            terminalDigitSort += name[10];
            terminalDigitSort += name[11];
         }
         //4301 Files
         else if (Regex.IsMatch(name, @"^\d*_\d*$"))
         {
            string[] segments = name.Split('_');
            for (int s = 0; s < segments.Length; s++)
            {
               string segment = segments[s];
               int d = segment.Length - 1;
               while (d >= 0)
               {
                  if (d >= 1)
                  {
                     terminalDigitSort += segment[d - 1];
                     terminalDigitSort += segment[d];
                     d -= 2;
                  }
                  else
                  {
                     terminalDigitSort += segment[d];
                     d--;
                  }
               }
            }
         }

         return terminalDigitSort;
      }
   }
}
