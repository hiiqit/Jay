using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AdminImaging
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RegistryWriter rw = new RegistryWriter();
            if (!rw.VerifyDefaultLoginEntries(txtWinUserName.Text, txtWinPassword.Text))
            {
                MessageBox.Show("Invalid UserName/Password. Please retry.");
                txtWinPassword.Focus();  
            }
            else
                StartApp();
        }

        private void Login_Load(object sender, EventArgs e)
        {
        }

        private void StartApp()
        {
            this.Hide();  
            frmUploadTool fNew = new frmUploadTool();
            Program.LoggedInUser = txtWinUserName.Text;
            Program.Password = txtWinPassword.Text;
            fNew.ShowDialog();
            this.Close(); 
        }
    }
}