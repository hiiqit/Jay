using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Win32;
using System.DirectoryServices.AccountManagement;
using System.Security.Cryptography;
  
namespace AdminImaging
{
    class RegistryWriter
    {
        /// <summary>
        /// enable automatic login to windows , for the provided user name
        /// </summary>
        /// <param name="usr">string the user name</param>
        /// <param name="pwd">string the password</param>

        public void WriteDefaultLogin(string usr, string pwd)
        {
            RegistryKey rekey = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon");
            if (rekey == null)
                System.Windows.Forms.MessageBox.Show("There has been an erro while trying to write to windows registry");
            else
            {
                rekey.SetValue("AutoAdminLogon", "1");
                rekey.SetValue("DefaultUserName", usr);
                rekey.SetValue("DefaultPassword", Encrypt(pwd));
            }
            rekey.Close();
        }

        public void RemoveDefaultLogin()
        {
            RegistryKey rekey = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon");
            if (rekey == null)
                System.Windows.Forms.MessageBox.Show("There has been an erro while trying to write to windows registry");
            else
            {
                rekey.DeleteValue("DefaultUserName", false);
                rekey.DeleteValue("DefaultPassword", false);
                rekey.DeleteValue("AutoAdminLogon", false);
            }
            rekey.Close();
        }

        /// <summary>
        /// verifies if theres a default login configuration present in the system
        /// </summary>
        public bool VerifyDefaultLoginEntries(string strUserName, string strPassword)
        {
            try
            {
                //RegistryKey rekey = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon");
                //if (rekey.GetValue("DefaultUserName").ToString().Equals(null))
               //     return false;
                //else if (rekey.GetValue("DefaultPassword").ToString().Equals(null))
               //     return false;
               // else
                {
                    PrincipalContext pc = new PrincipalContext(ContextType.Domain, "SOM");
                    bool isValid = pc.ValidateCredentials(strUserName, strPassword);
                    return isValid;
                    //String strUserName = rekey.GetValue("DefaultUserName").ToString();
                    //String strPassword = rekey.GetValue("DefaultPassword").ToString();
                    //strPassword = Decrypt(strPassword);                     
                }
            }
            catch (Exception)
            {
                return false; 
            }
            finally
            {  
            }
        }

        public bool VerifyLoginClearText(String strUserName, String strPassword)
        {
            PrincipalContext pc = new PrincipalContext(ContextType.Domain, "SOM");
            bool isValid = pc.ValidateCredentials(@"SOM\" + strUserName, strPassword);
            return isValid;
        }

        public string Encrypt(string plainText)
        {
            if (plainText == null) throw new ArgumentNullException("plainText");

            //encrypt data
            var data = Encoding.Unicode.GetBytes(plainText);
            byte[] encrypted = ProtectedData.Protect(data, null, DataProtectionScope.LocalMachine);

            //return as base64 string
            return Convert.ToBase64String(encrypted);
        }

        public string Decrypt(string cipher)
        {
            if (cipher == null) throw new ArgumentNullException("cipher");

            //parse base64 string
            byte[] data = Convert.FromBase64String(cipher);

            //decrypt data
            byte[] decrypted = ProtectedData.Unprotect(data, null, DataProtectionScope.LocalMachine);
            return Encoding.Unicode.GetString(decrypted);
        }
    }
}

