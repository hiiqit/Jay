﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AdminImaging;

namespace TestProject1
{
   [TestClass]
   public class UnitTest1
   {
      [TestMethod]
      public void FinishFileName_Test1()
      {
         string fileName = "1997_0003-4503";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("03000345", sortedFileName);
      }

      [TestMethod]
      public void FinishFileName_Test2()
      {
         string fileName = "1997_5003-8003";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("03500380", sortedFileName);
      }

      [TestMethod]
      public void FinishFileName_Test3()
      {
         string fileName = "1997_8503-2204";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("03850422", sortedFileName);
      }

      [TestMethod]
      public void FinishFileName_Test4()
      {
         string fileName = "1997_INDEX";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("", sortedFileName);
      }



      [TestMethod]
      public void File4301Name_Test1()
      {
         string fileName = "017700_208400";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("007701008420", sortedFileName);
      }

      [TestMethod]
      public void File4301Name_Test2()
      {
         string fileName = "08500_209100";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("00850009120", sortedFileName);
      }

      [TestMethod]
      public void File4301Name_Test3()
      {
         string fileName = "08500_20918";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("0085018092", sortedFileName);
      }

      [TestMethod]
      public void File4301Name_Test4()
      {
         string fileName = "08500_2";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("008502", sortedFileName);
      }

      [TestMethod]
      public void NonMatchingName_Test1()
      {
         string fileName = "File1";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("", sortedFileName);
      }

      [TestMethod]
      public void NonMatchingName_Test2()
      {
         string fileName = "456-786_1243-3438";
         string sortedFileName = Helpers.ComputeTerminalDigitSort(fileName);

         Assert.AreEqual("", sortedFileName);
      }

      [TestMethod]
      public void ReplacementTest1()
      {
         string name = "Assistant Director's Files";

         name = FileNetActions.SanitizeClassName(name);

         Assert.AreEqual("AssistantDirectorsFiles", name);
      }

      [TestMethod]
      public void ReplacementTest2()
      {
         string name = "4301 Files";

         name = FileNetActions.SanitizeClassName(name);

         Assert.AreEqual("4301Files", name);
      }

      [TestMethod]
      public void ReplacementTest3()
      {
         string name = "Director's, Assistant Director's, and Emails";

         name = FileNetActions.SanitizeClassName(name);

         Assert.AreEqual("DirectorsAssistantDirectorsandEmails", name);
      }

      [TestMethod]
      public void ReplacementTest4()
      {
         string name = "";

         name = FileNetActions.SanitizeClassName(name);

         Assert.AreEqual("", name);
      }

      [TestMethod]
      public void ReplacementTest5()
      {
         string name = null;

         name = FileNetActions.SanitizeClassName(name);

         Assert.AreEqual("", name);
      }
   }
}
