﻿namespace AdminImaging
{
    partial class frmUploadTool
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUploadTool));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.sortTerminalDigit = new System.Windows.Forms.CheckBox();
            this.chkSubfolders = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbDocCategory = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtFolder = new System.Windows.Forms.TextBox();
            this.fdrBrowser = new System.Windows.Forms.FolderBrowserDialog();
            this.dgDetails = new System.Windows.Forms.DataGridView();
            this.DocName = new System.Windows.Forms.DataGridViewLinkColumn();
            this.DocTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DocType = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.DocSystem = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.DocDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DocSource = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RecordSeriesNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DocComments = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Error = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ctxMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.item1 = new System.Windows.Forms.ToolStripMenuItem();
            this.item2 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnUpload = new System.Windows.Forms.Button();
            this.prgLoading = new System.Windows.Forms.ProgressBar();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.prgBar = new System.Windows.Forms.ToolStripProgressBar();
            this.btnCopy = new System.Windows.Forms.Button();
            this.btnPaste = new System.Windows.Forms.Button();
            this.fileNetServerLink = new System.Windows.Forms.LinkLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.docAreaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.categoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.docTypeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).BeginInit();
            this.ctxMenu.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Meiryo", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 18);
            this.label1.TabIndex = 8;
            this.label1.Text = "Select Upload Folder";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.sortTerminalDigit);
            this.groupBox1.Controls.Add(this.chkSubfolders);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cmbDocCategory);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnReset);
            this.groupBox1.Controls.Add(this.btnBrowse);
            this.groupBox1.Controls.Add(this.txtFolder);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Font = new System.Drawing.Font("Meiryo", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(12, 33);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(696, 136);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Upload Options";
            // 
            // sortTerminalDigit
            // 
            this.sortTerminalDigit.AutoSize = true;
            this.sortTerminalDigit.Location = new System.Drawing.Point(404, 107);
            this.sortTerminalDigit.Name = "sortTerminalDigit";
            this.sortTerminalDigit.Size = new System.Drawing.Size(167, 22);
            this.sortTerminalDigit.TabIndex = 9;
            this.sortTerminalDigit.Text = "Sort by Terminal Digit";
            this.sortTerminalDigit.UseVisualStyleBackColor = true;
            // 
            // chkSubfolders
            // 
            this.chkSubfolders.AutoSize = true;
            this.chkSubfolders.Location = new System.Drawing.Point(198, 108);
            this.chkSubfolders.Name = "chkSubfolders";
            this.chkSubfolders.Size = new System.Drawing.Size(155, 22);
            this.chkSubfolders.TabIndex = 4;
            this.chkSubfolders.Text = "File Into SubFolders";
            this.chkSubfolders.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkSubfolders.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 18);
            this.label3.TabIndex = 6;
            this.label3.Text = "Document Area";
            // 
            // cmbDocCategory
            // 
            this.cmbDocCategory.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDocCategory.FormattingEnabled = true;
            this.cmbDocCategory.ItemHeight = 14;
            this.cmbDocCategory.Location = new System.Drawing.Point(198, 49);
            this.cmbDocCategory.Name = "cmbDocCategory";
            this.cmbDocCategory.Size = new System.Drawing.Size(373, 22);
            this.cmbDocCategory.TabIndex = 1;
            this.cmbDocCategory.SelectedIndexChanged += new System.EventHandler(this.cmbDocCategory_SelectedIndexChanged);
            this.cmbDocCategory.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmbDocCategory_MouseClick);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.ItemHeight = 14;
            this.comboBox1.Location = new System.Drawing.Point(198, 21);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(373, 22);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Meiryo", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 18);
            this.label2.TabIndex = 7;
            this.label2.Text = "Document Category";
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnReset.Location = new System.Drawing.Point(577, 48);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(101, 27);
            this.btnReset.TabIndex = 5;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            this.btnReset.MouseHover += new System.EventHandler(this.btnReset_MouseHover);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnBrowse.Location = new System.Drawing.Point(577, 77);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(101, 27);
            this.btnBrowse.TabIndex = 3;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            this.btnBrowse.MouseHover += new System.EventHandler(this.btnBrowse_MouseHover);
            // 
            // txtFolder
            // 
            this.txtFolder.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFolder.Location = new System.Drawing.Point(198, 79);
            this.txtFolder.Name = "txtFolder";
            this.txtFolder.Size = new System.Drawing.Size(373, 22);
            this.txtFolder.TabIndex = 2;
            this.txtFolder.TextChanged += new System.EventHandler(this.txtFolder_TextChanged);
            this.txtFolder.MouseHover += new System.EventHandler(this.txtFolder_MouseHover);
            // 
            // fdrBrowser
            // 
            this.fdrBrowser.RootFolder = System.Environment.SpecialFolder.MyComputer;
            // 
            // dgDetails
            // 
            this.dgDetails.AllowUserToAddRows = false;
            this.dgDetails.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            this.dgDetails.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DocName,
            this.DocTitle,
            this.DocType,
            this.DocSystem,
            this.DocDate,
            this.DocSource,
            this.RecordSeriesNo,
            this.DocComments,
            this.Error});
            this.dgDetails.ContextMenuStrip = this.ctxMenu;
            this.dgDetails.Location = new System.Drawing.Point(12, 175);
            this.dgDetails.Name = "dgDetails";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            this.dgDetails.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgDetails.Size = new System.Drawing.Size(1166, 418);
            this.dgDetails.TabIndex = 0;
            this.dgDetails.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgDetails_CellContentClick);
            this.dgDetails.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgDetails_ColumnHeaderMouseClick);
            this.dgDetails.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgDetails_DataError);
            this.dgDetails.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgDetails_KeyDown);
            // 
            // DocName
            // 
            this.DocName.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.DocName.DataPropertyName = "DocName";
            this.DocName.HeaderText = "File Name *";
            this.DocName.Name = "DocName";
            this.DocName.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DocName.Width = 150;
            // 
            // DocTitle
            // 
            this.DocTitle.DataPropertyName = "DocTitle";
            this.DocTitle.HeaderText = "Doc Title *";
            this.DocTitle.Name = "DocTitle";
            this.DocTitle.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DocTitle.Width = 150;
            // 
            // DocType
            // 
            this.DocType.DataPropertyName = "DocType";
            this.DocType.HeaderText = "Doc Type *";
            this.DocType.Items.AddRange(new object[] {
            "Managed Prescription Drug Program (MPDP)",
            "Management Report",
            "Cost Report",
            "CEM",
            "Health Care Rates",
            "Health Care Initiative Chapter Notebook"});
            this.DocType.Name = "DocType";
            this.DocType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DocType.Width = 230;
            // 
            // DocSystem
            // 
            this.DocSystem.DataPropertyName = "DocSystem";
            this.DocSystem.HeaderText = "System";
            this.DocSystem.Name = "DocSystem";
            // 
            // DocDate
            // 
            this.DocDate.DataPropertyName = "DocDate";
            this.DocDate.HeaderText = "Doc Date *";
            this.DocDate.Name = "DocDate";
            this.DocDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // DocSource
            // 
            this.DocSource.DataPropertyName = "DocSource";
            this.DocSource.HeaderText = "Source ID *";
            this.DocSource.MaxInputLength = 10;
            this.DocSource.Name = "DocSource";
            this.DocSource.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // RecordSeriesNo
            // 
            this.RecordSeriesNo.DataPropertyName = "RecordSeriesNo";
            this.RecordSeriesNo.HeaderText = "Rec Series No";
            this.RecordSeriesNo.MaxInputLength = 50;
            this.RecordSeriesNo.Name = "RecordSeriesNo";
            this.RecordSeriesNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RecordSeriesNo.Width = 115;
            // 
            // DocComments
            // 
            this.DocComments.DataPropertyName = "DocComments";
            this.DocComments.HeaderText = "Comments";
            this.DocComments.MaxInputLength = 500;
            this.DocComments.Name = "DocComments";
            this.DocComments.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DocComments.Width = 175;
            // 
            // Error
            // 
            this.Error.HeaderText = "Error";
            this.Error.Name = "Error";
            this.Error.ReadOnly = true;
            // 
            // ctxMenu
            // 
            this.ctxMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.item1,
            this.item2});
            this.ctxMenu.Name = "ctxMenu";
            this.ctxMenu.Size = new System.Drawing.Size(103, 48);
            // 
            // item1
            // 
            this.item1.Name = "item1";
            this.item1.Size = new System.Drawing.Size(102, 22);
            this.item1.Text = "Copy";
            this.item1.Click += new System.EventHandler(this.item1_Click);
            this.item1.MouseHover += new System.EventHandler(this.item1_MouseHover);
            // 
            // item2
            // 
            this.item2.Name = "item2";
            this.item2.Size = new System.Drawing.Size(102, 22);
            this.item2.Text = "Paste";
            this.item2.Click += new System.EventHandler(this.item2_Click);
            this.item2.MouseHover += new System.EventHandler(this.item2_MouseHover);
            // 
            // btnUpload
            // 
            this.btnUpload.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnUpload.Location = new System.Drawing.Point(616, 605);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(137, 27);
            this.btnUpload.TabIndex = 3;
            this.btnUpload.Text = "Start Upload";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            this.btnUpload.MouseHover += new System.EventHandler(this.btnUpload_MouseHover);
            // 
            // prgLoading
            // 
            this.prgLoading.Location = new System.Drawing.Point(759, 608);
            this.prgLoading.Name = "prgLoading";
            this.prgLoading.Size = new System.Drawing.Size(419, 24);
            this.prgLoading.TabIndex = 4;
            this.prgLoading.Visible = false;
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel,
            this.prgBar});
            this.statusStrip.Location = new System.Drawing.Point(0, 644);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1190, 22);
            this.statusStrip.TabIndex = 5;
            this.statusStrip.Text = "statusStrip1";
            // 
            // statusLabel
            // 
            this.statusLabel.BackColor = System.Drawing.SystemColors.Control;
            this.statusLabel.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.statusLabel.ForeColor = System.Drawing.Color.Maroon;
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(0, 17);
            this.statusLabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // prgBar
            // 
            this.prgBar.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.prgBar.Name = "prgBar";
            this.prgBar.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.prgBar.Size = new System.Drawing.Size(400, 16);
            // 
            // btnCopy
            // 
            this.btnCopy.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCopy.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnCopy.Location = new System.Drawing.Point(12, 608);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(75, 27);
            this.btnCopy.TabIndex = 6;
            this.btnCopy.Text = "Copy";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // btnPaste
            // 
            this.btnPaste.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaste.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnPaste.Location = new System.Drawing.Point(104, 608);
            this.btnPaste.Name = "btnPaste";
            this.btnPaste.Size = new System.Drawing.Size(75, 27);
            this.btnPaste.TabIndex = 7;
            this.btnPaste.Text = "Paste";
            this.btnPaste.UseVisualStyleBackColor = true;
            this.btnPaste.Click += new System.EventHandler(this.btnPaste_Click);
            // 
            // fileNetServerLink
            // 
            this.fileNetServerLink.AutoSize = true;
            this.fileNetServerLink.BackColor = System.Drawing.Color.GhostWhite;
            this.fileNetServerLink.Font = new System.Drawing.Font("Meiryo", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileNetServerLink.Location = new System.Drawing.Point(712, 0);
            this.fileNetServerLink.Name = "fileNetServerLink";
            this.fileNetServerLink.Size = new System.Drawing.Size(228, 24);
            this.fileNetServerLink.TabIndex = 2;
            this.fileNetServerLink.TabStop = true;
            this.fileNetServerLink.Text = "Connected to FileNet Server";
            this.fileNetServerLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.fileNetServerLink_LinkClicked);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1190, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.docAreaToolStripMenuItem,
            this.categoryToolStripMenuItem,
            this.docTypeToolStripMenuItem,
            this.toolStripMenuItem2});
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.newToolStripMenuItem.Text = "Create";
            // 
            // docAreaToolStripMenuItem
            // 
            this.docAreaToolStripMenuItem.Name = "docAreaToolStripMenuItem";
            this.docAreaToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.docAreaToolStripMenuItem.Text = "Document Area";
            this.docAreaToolStripMenuItem.Click += new System.EventHandler(this.docAreaToolStripMenuItem_Click);
            // 
            // categoryToolStripMenuItem
            // 
            this.categoryToolStripMenuItem.Name = "categoryToolStripMenuItem";
            this.categoryToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.categoryToolStripMenuItem.Text = "Document Category";
            this.categoryToolStripMenuItem.Click += new System.EventHandler(this.categoryToolStripMenuItem_Click);
            // 
            // docTypeToolStripMenuItem
            // 
            this.docTypeToolStripMenuItem.Name = "docTypeToolStripMenuItem";
            this.docTypeToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.docTypeToolStripMenuItem.Text = "Document Type";
            this.docTypeToolStripMenuItem.Click += new System.EventHandler(this.docTypeToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(118, 20);
            this.toolStripMenuItem1.Text = "Checkout/Checkin";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(181, 22);
            this.toolStripMenuItem2.Text = "MoveContent";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // frmUploadTool
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1190, 666);
            this.Controls.Add(this.fileNetServerLink);
            this.Controls.Add(this.btnPaste);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.prgLoading);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.dgDetails);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Meiryo", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmUploadTool";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Imaging and Onsite Records Upload Tool";
            this.Load += new System.EventHandler(this.frmUploadTool_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmUploadTool_KeyDown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDetails)).EndInit();
            this.ctxMenu.ResumeLayout(false);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbDocCategory;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtFolder;
        private System.Windows.Forms.FolderBrowserDialog fdrBrowser;
        private System.Windows.Forms.DataGridView dgDetails;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.ProgressBar prgLoading;
        private System.Windows.Forms.ContextMenuStrip ctxMenu;
        private System.Windows.Forms.ToolStripMenuItem item1;
        private System.Windows.Forms.ToolStripMenuItem item2;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel statusLabel;
        private System.Windows.Forms.ToolStripProgressBar prgBar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnCopy;
        private System.Windows.Forms.Button btnPaste;
        private System.Windows.Forms.LinkLabel fileNetServerLink;
        private System.Windows.Forms.CheckBox chkSubfolders;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem categoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem docTypeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem docAreaToolStripMenuItem;
        private System.Windows.Forms.DataGridViewLinkColumn DocName;
        private System.Windows.Forms.DataGridViewTextBoxColumn DocTitle;
        private System.Windows.Forms.DataGridViewComboBoxColumn DocType;
        private System.Windows.Forms.DataGridViewComboBoxColumn DocSystem;
        private System.Windows.Forms.DataGridViewTextBoxColumn DocDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DocSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn RecordSeriesNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn DocComments;
        private System.Windows.Forms.DataGridViewTextBoxColumn Error;
        private System.Windows.Forms.CheckBox sortTerminalDigit;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
    }
}

