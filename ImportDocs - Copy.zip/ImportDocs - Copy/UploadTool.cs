﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using FileNet.Api.Util;
using FileNet.Api.Core;
using FileNet.Api.Constants;
using FileNet.Api.Collection;
using FileNet.Api.Property;
using System.Collections;

using log4net;
using FileNet.Api.Meta;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Text.RegularExpressions;
using FileNet.Api.Exception;

namespace AdminImaging
{
   public partial class frmUploadTool : Form
   {
      private static readonly ILog log = LogManager.GetLogger(typeof(Program));

      FileNetConnector oFileNet = new FileNetConnector();
      IConnection FNConn;
      IDomain FNDomain;
      IObjectStore FNStore;
      System.Data.DataTable dt = new System.Data.DataTable();

      private string[] strCopyVals = new string[9] { "", "", "", "", "", "", "", "", "" };

      private ExcelPackage ExcelPackage;
      private Int32 iDocSuccessCount = 0;
      private Int32 iDocFailureCount = 0;

      private String DocAreaText = "";
      private String DocCategorySelectedText = "";
      private String FolderSelectedText = "";


      private bool _UploadCancelled = false;
      private ArrayList aryDocSystems = new ArrayList();
      private ArrayList aryDocTypes = new ArrayList();

      public string strFolderPath = "";

      public frmUploadTool()
      {
         InitializeComponent();
      }

      private void InitializeObjects()
      {
         FNConn = oFileNet.getConnection(Program.LoggedInUser, Program.Password);
         FNDomain = oFileNet.getDomain(FNConn);
         FNStore = oFileNet.getObjectStore(FNDomain);
      }

      private void InitializeControls()
      {
         txtFolder.Text = "";
         SetDataTable();
         prgBar.Visible = false;
      }

      private void btnBrowse_Click(object sender, EventArgs e)
      {
         statusLabel.Text = "Help: Select the folder that needs to be uploaded.";
         fdrBrowser.ShowDialog();
         txtFolder.Text = fdrBrowser.SelectedPath;

         txtFolder.Focus();
      }

      private void SetListDetails()
      {
         try
         {
            log.Info("Folder Selected - " + txtFolder.Text);
            statusLabel.Text = "Files are populated now.";

            if (txtFolder.Text == "")
               return;

            DirectoryInfo oDir = new DirectoryInfo(txtFolder.Text);
            if (oDir.Exists)
            {
               foreach (FileInfo oFile in oDir.GetFiles())
               {
                  AddRow(oFile.Name, oFile.Name.Replace(oFile.Extension, ""));
               }

               //process one sub directory deep for now
               var subDirectories = oDir.GetDirectories();
               chkSubfolders.Checked = subDirectories.Length > 0;
               foreach (DirectoryInfo oSubDir in subDirectories.Where(d => d.Exists))
               {
                  foreach (FileInfo oFile in oSubDir.GetFiles())
                  {
                     AddRow(Path.Combine(oSubDir.Name, oFile.Name), oFile.Name.Replace(oFile.Extension, ""));
                  }
               }
            }
            else
            {
               MessageBox.Show("Please check your Upload Folder path.", "Admin Imaging - Select Upload Folder", MessageBoxButtons.OK);
            }

            BindingSource oBS = new BindingSource();
            oBS.DataSource = dt;
            dgDetails.DataSource = oBS;

            DataGridViewComboBoxColumn columncb = (DataGridViewComboBoxColumn)this.dgDetails.Columns["DocType"];
            columncb.DataSource = aryDocTypes;

            DataGridViewComboBoxColumn columncb1 = (DataGridViewComboBoxColumn)this.dgDetails.Columns["DocSystem"];
            columncb1.DataSource = aryDocSystems;

            dgDetails.Refresh();

            log.Info("Files added to the grid - " + dgDetails.RowCount.ToString());
         }
         catch (Exception exc)
         {
            MessageBox.Show("Error occured populating the files. Please exit application and retry.");
            log.Error("Error occured populating the files. Please exit application and retry.", exc);
         }

      }

      private void SetDataTable()
      {
         // define the table's schema
         dt.Columns.Add(new DataColumn("DocName", typeof(string)));
         dt.Columns.Add(new DataColumn("DocTitle", typeof(string)));
         dt.Columns.Add(new DataColumn("DocType", typeof(string)));
         dt.Columns.Add(new DataColumn("DocDate", typeof(DateTime)));
         dt.Columns.Add(new DataColumn("DocSource", typeof(string)));
         dt.Columns.Add(new DataColumn("RecordSeriesNo", typeof(string)));
         dt.Columns.Add(new DataColumn("DocComments", typeof(string)));
      }

      private void AddRow(String DocFullName, String DocTitle)
      {
         DataRow dr = dt.NewRow();
         dr["DocName"] = DocFullName;
         dr["DocTitle"] = DocTitle;
         dt.Rows.Add(dr);
      }

      public void SetDocumentCategories(string stringFolderPath)
      {
         if (string.IsNullOrEmpty(stringFolderPath)) { return; }

         if (cmbDocCategory.Items.Count > 0)
         {
            cmbDocCategory.Items.Clear();
         }

         try
         {
            IFolder folder = Factory.Folder.FetchInstance(FNStore, "/" + stringFolderPath, null);

            foreach (IFolder subFolder in folder.SubFolders)
            {
               if (subFolder.Name == "Logs") { continue; }

               cmbDocCategory.Items.Add(subFolder.Name);
            }
            cmbDocCategory.Sorted = true;
         }
         catch (Exception exc)
         {
            MessageBox.Show("Error retrieving document categories. Please exit application and retry.");
            log.Error("Error retrieving document categories. Please exit application and retry.", exc);
         }

      }

      private void SetDocTypes()
      {
         try
         {
            aryDocTypes = new ArrayList();

            IFolder folder = Factory.Folder.FetchInstance(FNStore, "/" + comboBox1.SelectedItem.ToString() + "/" + cmbDocCategory.SelectedItem.ToString(), null);

            foreach (IFolder subFolder in folder.SubFolders)
            {
               if (subFolder.Name == "Logs")
               {
                  continue;
               }

               aryDocTypes.Add(subFolder.Name);
            }
            aryDocTypes.Sort();
         }
         catch (Exception exc)
         {
            MessageBox.Show("Error retrieving document types. Please exit application and retry.");
            log.Error("Error retrieving document types. Please exit application and retry.", exc);
         }
      }

      private void SetDocSystems()
      {
         try
         {
            aryDocSystems = new ArrayList();

            foreach (FileNet.Api.Admin.IChoiceList RootChoiceList in FNStore.ChoiceLists)
            {
               if (RootChoiceList.Name.Equals("DocSystems", StringComparison.OrdinalIgnoreCase))
               {
                  foreach (FileNet.Api.Admin.IChoice oValuesList in RootChoiceList.ChoiceValues)
                  {
                     aryDocSystems.Add(oValuesList.ChoiceStringValue);
                  }
                  break;
               }
            }
            this.aryDocSystems.Sort();
         }
         catch (Exception exc)
         {
            MessageBox.Show("Error retrieving document types. Please exit application and retry.");
            log.Error("Error retrieving document types. Please exit application and retry.", exc);
         }
      }

      private void cmbDocCategory_SelectedIndexChanged(object sender, EventArgs e)
      {
         Log("Doc Category Selected - " + cmbDocCategory.Text);

         if (cmbDocCategory.Text == DocCategorySelectedText)
            return;

         if (dgDetails.RowCount > 0)
         {
            DialogResult result;
            result = MessageBox.Show("Selecting a different document category now will repopulate the rows below. Do you want to continue?", "Document Category Change", MessageBoxButtons.YesNo);
            Log("Selecting a different document category now will repopulate the rows below. Do you want to continue?");
            if (result == DialogResult.Yes)
            {
               Log("Yes");
               ClearDataGridRows();
            }
            else
            {
               Log("No");
               cmbDocCategory.Text = DocCategorySelectedText;
               return;
            }
         }

         DocCategorySelectedText = cmbDocCategory.Text;
         SetDocTypes();
         Log("Doc Types Set.");

         SetDocSystems();
         Log("Document Systems retrieved and set.");

         SetListDetails();
         Log("Grid Populated.");
      }

      private void dgDetails_DataError(object sender, DataGridViewDataErrorEventArgs e)
      {
         try
         {
            var row = dgDetails.Rows[e.RowIndex];
            var cell = row.Cells[e.ColumnIndex];

            statusLabel.Text = "";
            if (cell.ColumnIndex == 4)
            {
               MessageBox.Show("Please enter a valid document date.", "Admin Imaging Date Validation");
               dgDetails.CurrentCell = cell;
               dgDetails.BeginEdit(true);
            }
         }
         catch (Exception) { }
      }

      private void dgDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
      {
         try
         {
            var row = dgDetails.Rows[e.RowIndex];
            var cell = row.Cells[e.ColumnIndex];

            if (dgDetails.Focused && cell.ColumnIndex == dgDetails.Columns["DocName"].Index)
            {
               if (cell.Value != null)
               {
                  Process.Start(Path.Combine(txtFolder.Text, cell.Value.ToString()));
               }
            }
         }
         catch (Exception) { }
      }

      private void dgDetails_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
      {
         try
         {
            if (this.dgDetails.SelectedCells.Count > 0)
            {
               if (e.KeyCode == Keys.Delete)
               {
                  NavigateCells_Command("DEL");
               }
               else if (e.Control && e.KeyCode == Keys.C)
               {
                  CopyCells();
                  e.Handled = true;
               }
               else if (e.Control && e.KeyCode == Keys.V)
               {
                  NavigateCells_Command("PASTE");
                  e.Handled = true;
               }
            }
         }
         catch (Exception) { }
      }

      private void SetupExcel(DataGridView datagridview, bool captions)
      {
         try
         {
            if (ExcelPackage != null)
            {
               ExcelPackage.Dispose();
               ExcelPackage = null;
            }

            ExcelPackage = new OfficeOpenXml.ExcelPackage();
            ExcelWorksheet worksheet = ExcelPackage.Workbook.Worksheets.Add("UploadLog");

            worksheet.DefaultColWidth = 30;

            worksheet.Cells[1, 1].Value = "File Name";
            worksheet.Cells[1, 2].Value = "Doc Title";
            worksheet.Cells[1, 3].Value = "Doc Type";
            worksheet.Cells[1, 4].Value = "Doc System";
            worksheet.Cells[1, 5].Value = "Doc Date";
            worksheet.Cells[1, 6].Value = "Source ID";
            worksheet.Cells[1, 7].Value = "Record Series No";
            worksheet.Cells[1, 8].Value = "Comments";
            worksheet.Cells[1, 9].Value = "UploadSuccess?";
            worksheet.Cells[1, 10].Value = "DocID";
            worksheet.Cells[1, 11].Value = "Update Date";

            ExcelRow firstRow = worksheet.Row(1);
            firstRow.Style.Font.Bold = true;
            firstRow.Style.Font.Color.SetColor(Color.White);
            firstRow.Style.Fill.PatternType = ExcelFillStyle.Solid;
            firstRow.Style.Fill.BackgroundColor.SetColor(Color.Green);

            log.Info("Excel ready.");
         }
         catch (Exception exc)
         {
            log.Error("Excel Create Error.", exc);
            MessageBox.Show("Please exit application and retry.");
            _UploadCancelled = true;
         }
      }

      private void SaveExcel()
      {
         String strExcelFileName = DateTime.Now.ToString().Replace("/", "").Replace(":", "") + ".xlsx";
         try
         {
            String strFolderPath = @"C:\temp\";
            if (!Directory.Exists(strFolderPath))
               strFolderPath = @"C:\";

            String strTmpExcelFileName = strFolderPath + strExcelFileName;

            ExcelWorksheet worksheet = ExcelPackage.Workbook.Worksheets["UploadLog"];
            ExcelPackage.SaveAs(new FileInfo(strTmpExcelFileName));

            Log("Excel saved under - " + strTmpExcelFileName);

            SaveLogtoFileNet(strTmpExcelFileName);
         }
         catch (Exception)
         {

         }
         finally
         {
            if (ExcelPackage != null)
            {
               ExcelPackage.Dispose();
               ExcelPackage = null;
            }
         }
      }

      private void item1_Click(object sender, EventArgs e)
      {
         CopyCells();
      }

      private void item2_Click(object sender, EventArgs e)
      {
         NavigateCells_Command("PASTE");
      }

      private void CopyCells()
      {
         try
         {
            int docNameIndex = dgDetails.Columns["DocName"].Index;
            int dotTitleIndex = dgDetails.Columns["DocTitle"].Index;

            foreach (DataGridViewCell cell in dgDetails.SelectedCells.OfType<DataGridViewCell>().Where(c => c.ColumnIndex != docNameIndex && c.ColumnIndex != dotTitleIndex && c.Value != null))
            {
               strCopyVals[cell.ColumnIndex] = cell.Value.ToString();
            }
         }
         catch (Exception) { }
      }

      private void NavigateCells_Command(String doFunction)
      {
         bool delete = doFunction == "DEL";
         bool paste = doFunction == "PASTE";

         int docNameIndex = dgDetails.Columns["DocName"].Index;
         int dotTitleIndex = dgDetails.Columns["DocTitle"].Index;

         if (delete)
         {
            foreach (DataGridViewCell cell in dgDetails.SelectedCells)
            {
               try
               {
                  cell.Value = "";
               }
               catch (Exception) { }
            }
         }
         else if (paste)
         {
            foreach (DataGridViewCell cell in dgDetails.SelectedCells.OfType<DataGridViewCell>().Where(c => c.ColumnIndex != docNameIndex && c.ColumnIndex != dotTitleIndex))
            {
               try
               {
                  cell.Value = strCopyVals[cell.ColumnIndex];
               }
               catch (Exception) { }
            }
         }

         dgDetails.Refresh();
      }

      private void EnableProgressBar()
      {
         prgBar.Visible = true;
         prgBar.Value = 0;
         prgBar.Minimum = 0;
         prgBar.Maximum = dgDetails.Rows.OfType<DataGridViewRow>().Count(r => !r.ReadOnly);
         prgBar.Step = 1;
      }

      private void btnUpload_Click(object sender, EventArgs e)
      {
         Log("Upload Process started.");

         if (btnUpload.Text == "Cancel Upload")
         {
            _UploadCancelled = true;
            return;
         }
         else
            _UploadCancelled = false;

         //Validation Routine
         if (!ValidateData())
            return;

         btnUpload.Text = "Cancel Upload";

         statusLabel.Text = "Setting up Excel Report...";
         SetupExcel(dgDetails, true);

         statusLabel.Text = "Upload Process started now. Please wait...";
         EnableProgressBar();

         PerformUpload();

         SaveExcel();

         #region ProgressBar
         prgBar.PerformStep();
         prgBar.Visible = false;
         #endregion

         statusLabel.Text = "Saving Excel Report...";
         statusLabel.Text = "Excel Report Saved...";

         if (!_UploadCancelled)
         {
            if (iDocFailureCount == 0)
            {
               MessageBox.Show("All documents are uploaded successfully." + Environment.NewLine +
                               "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                               "Failure Documents Count - " + iDocFailureCount.ToString(), "Upload Status", MessageBoxButtons.OK, MessageBoxIcon.Information);

               log.Info("All documents are uploaded successfully." + Environment.NewLine +
                               "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                               "Failure Documents Count - " + iDocFailureCount.ToString());
            }
            else
            {
               MessageBox.Show("There are some failures during the upload process!" + Environment.NewLine +
                               "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                               "Failure Documents Count - " + iDocFailureCount.ToString(), "Upload Status", MessageBoxButtons.OK, MessageBoxIcon.Error);

               log.Info("There are some failures during the upload process!" + Environment.NewLine +
                               "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                               "Failure Documents Count - " + iDocFailureCount.ToString());
            }
         }
         else
         {
            MessageBox.Show("Few documents got uploaded before the upload was cancelled." + Environment.NewLine +
                         "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                         "Failure Documents Count - " + iDocFailureCount.ToString(), "Upload Status", MessageBoxButtons.OK, MessageBoxIcon.Information);

            log.Info("Few documents got uploaded before the upload was cancelled." + Environment.NewLine +
                            "Success Documents Count - " + iDocSuccessCount.ToString() + Environment.NewLine +
                            "Failure Documents Count - " + iDocFailureCount.ToString());
         }

         //prgBar.Refresh();            
         btnUpload.Text = "Start Upload";
         statusLabel.Text = "Upload completed.";

         Log("Upload Process Completed.");
      }

      private void SaveLogtoFileNet(String strPath)
      {
         // Create a document instance
         IDocument doc = Factory.Document.CreateInstance(FNStore, "Document");
         FileInfo oLogFile = new FileInfo(strPath);

         doc.Properties["DocumentTitle"] = oLogFile.Name;
         doc.MimeType = "application/vnd.ms-excel";

         // Specify internal and external files to be added as content.
         Stream internalFile = File.OpenRead(strPath);
         Log("local log file read.");
         // Add content to the Reservation object
         try
         {
            // First, add a ContentTransfer object.
            IContentTransfer ctObject = Factory.ContentTransfer.CreateInstance();
            IContentElementList contentList = Factory.ContentTransfer.CreateList();
            ctObject.SetCaptureSource(internalFile);
            // Add ContentTransfer object to list
            ctObject.ContentType = doc.MimeType;
            ctObject.RetrievalName = oLogFile.Name;
            contentList.Add(ctObject);

            doc.ContentElements = contentList;
            doc.Save(RefreshMode.REFRESH);
            Log("Content Elements added.");

            doc.Checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
            doc.Save(RefreshMode.NO_REFRESH);
            Log("Doc Checked in.");

            String strFolderPath = "/" + comboBox1.SelectedItem.ToString() + "/Logs/";

            // File the document in a folder
            IFolder folder = Factory.Folder.GetInstance(FNStore, ClassNames.FOLDER, strFolderPath);
            IReferentialContainmentRelationship rcr = folder.File(doc,
                    AutoUniqueName.AUTO_UNIQUE, oLogFile.Name,
                    DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
            rcr.Save(RefreshMode.NO_REFRESH);
            Log("Doc filed under folder path - " + strFolderPath);
         }
         catch (Exception exc)
         {
            MessageBox.Show(exc.Message);
            log.Error("Log File Upload Failed. Please make sure the Excel Log file is uploaded into FileNet by your FileNet Administrator.", exc);
         }
         finally
         {
            doc = null;
            oLogFile = null;
            internalFile.Close();
            internalFile.Dispose();
         }

      }

      private void PerformUpload()
      {
         bool blnDocSuccess;
         IDocument doc = null;
         iDocFailureCount = 0;
         iDocSuccessCount = 0;
         TimeSpan ts = new TimeSpan(5, 0, 0);

         int i = 0;
         foreach (DataGridViewRow row in dgDetails.Rows.OfType<DataGridViewRow>().Where(r => !r.ReadOnly))
         {
            if (_UploadCancelled)
               break;

            blnDocSuccess = false;

            string docName = row.Cells["DocName"].Value.ToString();
            string docTitle = row.Cells["DocTitle"].Value.ToString();
            string docType = row.Cells["DocType"].Value.ToString();

            if (chkSubfolders.Checked)
            {
               docType = docName.Split('\\')[0];
            }

            object docSystem = row.Cells["DocSystem"].Value;
            string docSystemString = docSystem != null ? docSystem.ToString() : "";
            string docDate = row.Cells["DocDate"].Value.ToString();
            DateTime docDateTime = isDate(docDate) ? Convert.ToDateTime(docDate) : DateTime.MinValue;
            string docSource = row.Cells["DocSource"].Value.ToString();
            string recSeriesNo = row.Cells["RecordSeriesNo"].Value.ToString();
            string docComments = row.Cells["DocComments"].Value.ToString();

            //clear any errors if there are any
            row.Cells["Error"].Value = "";

            try
            {
               #region Update Doc Properties

               string className = "Document_" + FileNetActions.SanitizeClassName(comboBox1.Text) + "_" + FileNetActions.SanitizeClassName(cmbDocCategory.Text);
               if (className.Length > 64)
               {
                  className = className.Substring(0, 64);
               }

               // Create a document instance
               try
               {
                  doc = Factory.Document.CreateInstance(FNStore, className);
               }
               catch (EngineRuntimeException ere)
               {
                  ExceptionCode code = ere.GetExceptionCode();
                  if (code != ExceptionCode.E_BAD_CLASSID)
                  {
                     throw ere;
                  }

                  //fall back to the old way of doing classes for Admin Imaging
                  className = FileNetActions.SanitizeClassName(cmbDocCategory.Text);

                  doc = Factory.Document.CreateInstance(FNStore, className);
               }

               // Set document properties
               switch (System.IO.Path.GetExtension(docName).ToLower())
               {
                  case ".pdf":
                     doc.MimeType = "application/pdf";
                     break;
                  case ".tif":
                     doc.MimeType = "application/tif";
                     break;
                  case ".tiff":
                     doc.MimeType = "application/tif";
                     break;
                  case ".rtf":
                     doc.MimeType = "application/msword";
                     break;
                  case ".doc":
                     doc.MimeType = "application/msword";
                     break;
                  case ".docx":
                     doc.MimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                     break;
               }
               Log("Row - " + i.ToString());
               Log("FilePath - " + txtFolder.Text + @"\" + docName);

               doc.Properties["DocumentTitle"] = docTitle;
               Log("DocumentTitle - " + docTitle);

               doc.Properties["DocumentType"] = docType;
               Log("DocumentType - " + docType);

               if (docSystem != null)
               {
                  doc.Properties["DocumentSystem"] = docSystemString;
                  Log("DocumentSystem - " + docSystemString);
               }
               else
                  Log("DocumentSystem - ");

               if (docDateTime != DateTime.MinValue)
               {
                  doc.Properties["DocumentDate"] = docDateTime;
                  Log("DocumentDate - " + docDate);
               }
               else
                  Log("DocumentDate - Empty");

               doc.Properties["SourceID"] = docSource;
               Log("SourceID - " + docSource);

               doc.Properties["RecordSeriesNo"] = recSeriesNo;
               Log("RecordSeriesNo - " + recSeriesNo);

               doc.Properties["Comments"] = docComments;
               Log("Comments - " + docComments);

               if (sortTerminalDigit.Checked)
               {
                  string terminalDigitSort = Helpers.ComputeTerminalDigitSort(docTitle);

                  //only do the sort if we made a match and were able to rearrage it
                  if (!string.IsNullOrEmpty(terminalDigitSort))
                  {
                     doc.Properties["TerminalDigitSort"] = terminalDigitSort;
                     Log("TerminalDigitSort - " + terminalDigitSort);
                  }
               }

               doc.Save(RefreshMode.NO_REFRESH);

               #endregion

               #region UploadDoc

               // Specify internal and external files to be added as content.
               Stream internalFile = File.OpenRead(txtFolder.Text + @"\" + docName);
               Log("local file read.");
               // Add content to the Reservation object

               // First, add a ContentTransfer object.
               IContentTransfer ctObject = Factory.ContentTransfer.CreateInstance();
               IContentElementList contentList = Factory.ContentTransfer.CreateList();
               ctObject.SetCaptureSource(internalFile);

               // Add ContentTransfer object to list
               ctObject.ContentType = doc.MimeType;
               ctObject.RetrievalName = docName;
               contentList.Add(ctObject);

               doc.ContentElements = contentList;
               doc.Save(RefreshMode.REFRESH);
               Log("Content Elements added.");

               doc.Checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
               doc.Save(RefreshMode.NO_REFRESH);
               Log("Doc Checked in.");

               strFolderPath = "/" + comboBox1.SelectedItem.ToString() + "/" + cmbDocCategory.Text + "/" + docType;
               string baseFolderPath = "/" + comboBox1.SelectedItem.ToString() + "/" + cmbDocCategory.Text;

               // File the document in a folder
               IFolder folder;
               try
               {
                  //try to get the subfolder
                  folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);
               }
               catch (Exception)
               {
                  //create it and then use it for the document upload
                  IFolder rootFolder = Factory.Folder.FetchInstance(FNStore, baseFolderPath, null);
                  folder = rootFolder.CreateSubFolder(docType);
                  folder.Save(RefreshMode.REFRESH);

                  IClassDescription rootFolderClassDescription = rootFolder.ClassDescription;

                  folder = Factory.Folder.FetchInstance(FNStore, strFolderPath, null);
                  folder.ChangeClass(rootFolderClassDescription.SymbolicName);
                  folder.Save(RefreshMode.REFRESH);
               }

               IReferentialContainmentRelationship rcr = folder.File(doc,
                       AutoUniqueName.AUTO_UNIQUE, docTitle,
                       DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);
               rcr.Save(RefreshMode.NO_REFRESH);
               Log("Doc filed under folder path - " + strFolderPath);

               blnDocSuccess = true;
               iDocSuccessCount++;
               row.ReadOnly = true;

               #endregion
            }
            catch (Exception exc)
            {
               row.Cells["Error"].Value = exc.Message;
               log.Error("Doc Upload Failed - please contact FileNet Administrator for further assistance.", exc);
               row.DefaultCellStyle.BackColor = Color.LightPink;
               iDocFailureCount++;
            }

            #region Excel Update

            ExcelWorksheet worksheet = ExcelPackage.Workbook.Worksheets["UploadLog"];
            try
            {
               if (!string.IsNullOrEmpty(docName))
               {
                  worksheet.Cells[i + 2, 1].Value = docName;
                  worksheet.Cells[i + 2, 2].Value = docTitle;
                  worksheet.Cells[i + 2, 3].Value = docType;

                  if (docSystem != null)
                  {
                     worksheet.Cells[i + 2, 4].Value = docSystemString;
                  }

                  worksheet.Cells[i + 2, 5].Value = docDate;
                  worksheet.Cells[i + 2, 6].Value = docSource;
                  worksheet.Cells[i + 2, 7].Value = recSeriesNo;
                  worksheet.Cells[i + 2, 8].Value = docComments;
               }

               //Upload Success Status
               if (blnDocSuccess)
               {
                  worksheet.Cells[i + 2, 9].Value = "Yes";
                  worksheet.Cells[i + 2, 10].Value = doc.Id;
                  worksheet.Cells[i + 2, 11].Value = doc.DateCreated.Value.Subtract(ts).ToString();
                  row.DefaultCellStyle.BackColor = Color.Wheat;
               }
               else
               {
                  worksheet.Cells[i + 2, 9].Value = "No";
               }

               worksheet.Cells[i + 2, 1].AutoFitColumns();
               worksheet.Cells[i + 2, 2].AutoFitColumns();
               worksheet.Cells[i + 2, 3].AutoFitColumns();
               worksheet.Cells[i + 2, 4].AutoFitColumns();
               worksheet.Cells[i + 2, 5].AutoFitColumns();
               worksheet.Cells[i + 2, 6].AutoFitColumns();
               worksheet.Cells[i + 2, 7].AutoFitColumns();
               worksheet.Cells[i + 2, 8].AutoFitColumns();
               worksheet.Cells[i + 2, 9].AutoFitColumns();
               worksheet.Cells[i + 2, 10].AutoFitColumns();
               worksheet.Cells[i + 2, 11].AutoFitColumns();

               Log("Excel row added.");
            }
            catch (Exception)
            {
            }

            #endregion

            dgDetails.Refresh();

            #region ProgressBar
            prgBar.PerformStep();
            #endregion
            System.Windows.Forms.Application.DoEvents();

            i++;
         }
      }

      private bool ValidateData()
      {
         String strField;

         if (dgDetails.RowCount == 0)
         {
            MessageBox.Show("There are no records/documents to be uploaded. Please reset and try again.", "Admin Imaging Upload Validation");
            return false;
         }

         foreach (DataGridViewRow row in dgDetails.Rows)
         {
            strField = "";
            if (row.Cells["DocName"].Value.ToString() == "")
               strField = "DocName";
            else if (row.Cells["DocTitle"].Value.ToString() == "")
               strField = "DocTitle";
            else if (row.Cells["DocType"].Value.ToString() == "" && aryDocTypes.Count > 0 && !chkSubfolders.Checked)
               strField = "DocType";
            else if (row.Cells["DocDate"].Value.ToString() == "")
               strField = "DocDate";
            else if (row.Cells["DocSource"].Value.ToString() == "")
               strField = "DocSource";

            if (strField != "")
            {
               MessageBox.Show("Please fill data for all required fields.");
               statusLabel.Text = "Please fill data for all required fields.";
               dgDetails.CurrentCell = row.Cells[strField];
               dgDetails.BeginEdit(true);
               return false;
            }

            if (row.Cells["DocDate"].Value.ToString() != "")
            {
               if (isDate(row.Cells["DocDate"].Value.ToString()) == false)
               {
                  MessageBox.Show("Please fill in valid value for the date field.");
                  statusLabel.Text = "Please fill in valid value for the date field.";
                  dgDetails.CurrentCell = row.Cells["DocDate"];
                  dgDetails.BeginEdit(true);
                  return false;
               }
            }
         }
         Log("Validation Successful.");
         statusLabel.Text = "Validation completed.";
         return true;
      }

      private bool isDate(String value)
      {
         DateTime date;
         return DateTime.TryParse(value, out date);
      }

      private void btnReset_Click(object sender, EventArgs e)
      {
         statusLabel.Text = "Help: Resetting will clear all the fields in the application.";
         DialogResult result = MessageBox.Show("Are you sure you want to reset the fields?", "Reset Fields", MessageBoxButtons.YesNo);
         Log("Are you sure you want to reset the fields?");
         if (result == DialogResult.Yes)
         {
            Log("Yes");
            ResetFields();
         }
      }

      private void ResetFields()
      {
         ClearDataGridRows();

         txtFolder.Text = "";
         cmbDocCategory.Text = "";
         comboBox1.Text = "";

         DocCategorySelectedText = "";
         FolderSelectedText = "";
         DocAreaText = "";

         SetupDocumentAreas();
         cmbDocCategory.Items.Clear();

         for (int i = 0; i < strCopyVals.Length; i++)
         {
            strCopyVals[i] = "";
         }

         Log("Fields are reset now.");
      }

      private void ClearDataGridRows()
      {
         for (int i = dgDetails.Rows.Count - 1; i >= 0; i--)
         {
            dgDetails.Rows.RemoveAt(i);
         }

         Log("Data Grid Rows cleared.");
      }

      private void txtFolder_TextChanged(object sender, EventArgs e)
      {
         if (txtFolder.Text == FolderSelectedText)
         {
            return;
         }

         if (dgDetails.RowCount > 0)
         {
            DialogResult result;
            result = MessageBox.Show("Selecting a different folder now will reset the data below. Do you want to continue?", "Folder Change", MessageBoxButtons.YesNo);
            Log("Selecting a different folder now will reset the data below. Do you want to continue?");
            if (result == DialogResult.Yes)
            {
               Log("Yes");
               ClearDataGridRows();
            }
            else
            {
               Log("No");
               txtFolder.Text = FolderSelectedText;
               return;
            }
         }

         FolderSelectedText = txtFolder.Text;

         SetDocTypes();
         Log("Doc Types Set.");

         SetDocSystems();
         Log("Document Systems retrieved and set.");

         SetListDetails();
         Log("Grid Populated.");
      }

      private void Log(String strMsg)
      {
         if (log.IsDebugEnabled)
         {
            log.Debug(strMsg);
         }
      }

      private void frmUploadTool_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
      {
         if (e.KeyCode == Keys.Escape)
         {
            if (btnUpload.Text == "Cancel Upload")
            {
               _UploadCancelled = true;
            }
            e.Handled = true;
         }
      }

      private void cmbDocCategory_MouseClick(object sender, System.Windows.Forms.MouseEventArgs e)
      {
         statusLabel.Text = "Help: Please select the Document Category that needs to be associated for the files to be uploaded.";
      }

      private void txtFolder_MouseHover(object sender, System.EventArgs e)
      {
         statusLabel.Text = "Help: Select/Enter the folder that needs to be uploaded.";
      }

      private void btnBrowse_MouseHover(object sender, System.EventArgs e)
      {
         statusLabel.Text = "Help: Select the folder that needs to be uploaded.";
      }

      private void btnReset_MouseHover(object sender, System.EventArgs e)
      {
         statusLabel.Text = "Help: Resetting will clear all the fields in the application.";
      }

      private void btnUpload_MouseHover(object sender, System.EventArgs e)
      {
         statusLabel.Text = "Help: When you click this button, upload process will be started.";
      }

      private void item1_MouseHover(object sender, System.EventArgs e)
      {
         statusLabel.Text = "Help: This action would copy the content from the current cell you are in.";
      }

      private void item2_MouseHover(object sender, System.EventArgs e)
      {
         statusLabel.Text = "Help: This action would paste the content for all the selected cells.";
      }

      private void SetupDocumentAreas()
      {
         if (comboBox1.Items.Count > 0)
         {
            comboBox1.Items.Clear();
         }

         //setup document areas
         IFolder folder = Factory.Folder.FetchInstance(FNStore, "/", null);
         foreach (IFolder subFolder in folder.SubFolders)
         {
            try
            {
               if ((Boolean)subFolder.Properties[FileNetConstants.DocumentAreaIndicator] == true)
               {
                  comboBox1.Items.Add(subFolder.Name);
               }
            }
            catch (Exception)
            {
            }

         }
         comboBox1.Sorted = true;
      }

      private void frmUploadTool_Load(object sender, EventArgs e)
      {
         this.Focus();
         InitializeControls();
         InitializeObjects();

         SetupDocumentAreas();
         SetDocumentCategories("");

         statusLabel.Text = "Help: Select a Document Type.";

         var serverUri = new Uri(AdminImaging.Properties.Settings.Default.AdminImaging_FileNet_FNCEWS40Service);
         fileNetServerLink.Text += " " + serverUri.Host;
      }

      private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
      {
         Log("Doc Type Selected - " + comboBox1.Text);
         if (comboBox1.Text == DocAreaText)
            return;

         if (dgDetails.RowCount > 0)
         {
            DialogResult result;
            result = MessageBox.Show("Selecting a different upload type now will repopulate the rows below. Do you want to continue?", "Document Category Change", MessageBoxButtons.YesNo);
            Log("Selecting a different document category now will repopulate the rows below. Do you want to continue?");
            if (result == DialogResult.Yes)
            {
               Log("Yes");
               ClearDataGridRows();
            }
            else
            {
               Log("No");
               comboBox1.Text = DocAreaText;
               return;
            }
         }

         DocAreaText = comboBox1.SelectedItem.ToString();
         DocCategorySelectedText = "";
         cmbDocCategory.Text = "";
         SetDocumentCategories(comboBox1.SelectedItem.ToString());
      }

      private void btnCopy_Click(object sender, EventArgs e)
      {
         CopyCells();
      }

      private void btnPaste_Click(object sender, EventArgs e)
      {
         NavigateCells_Command("PASTE");
      }

      private void fileNetServerLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
      {
         var serverUri = new Uri(AdminImaging.Properties.Settings.Default.AdminImaging_FileNet_FNCEWS40Service);
         System.Diagnostics.Process.Start(string.Format("http://{0}:9080/WorkplaceXT/ContainerLogin.jsp", serverUri.Host));
      }

      private void dgDetails_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
      {
         dgDetails.ClearSelection();

         foreach (DataGridViewRow row in dgDetails.Rows)
         {
            foreach (DataGridViewCell cell in row.Cells.OfType<DataGridViewCell>().Where(c => c.ColumnIndex == e.ColumnIndex))
            {
               cell.Selected = true;
            }
         }
      }

      private void categoryToolStripMenuItem_Click(object sender, EventArgs e)
      {
         var form = new AddDocumentCategory(FNStore);
         if (form.ShowDialog() == DialogResult.OK)
         {
            ResetFields();
         }
      }

      private void docAreaToolStripMenuItem_Click(object sender, EventArgs e)
      {
         var form = new AddDocumentArea(FNStore);
         if (form.ShowDialog() == DialogResult.OK)
         {
            ResetFields();
         }
      }

      private void docTypeToolStripMenuItem_Click(object sender, EventArgs e)
      {
         var form = new AddDocumentType(FNStore);
         if (form.ShowDialog() == DialogResult.OK)
         {
            ResetFields();
         }
      }

      private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
      {
         var form = new DeleteDocuments(FNStore);
         if (form.ShowDialog() == DialogResult.OK)
         {
            ResetFields();
         }
      }

      private void toolStripMenuItem1_Click(object sender, EventArgs e)
      {
          var form = new Form1(FNStore);
          if (form.ShowDialog() == DialogResult.OK)
          {
              ResetFields();
          }
      }

      private void toolStripMenuItem2_Click(object sender, EventArgs e)
      {
          var form = new Form1(FNStore);
          if (form.ShowDialog() == DialogResult.OK)
          {
              ResetFields();
          }
      }
   }
}
